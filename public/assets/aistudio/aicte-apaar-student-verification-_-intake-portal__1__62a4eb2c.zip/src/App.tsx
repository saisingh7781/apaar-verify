/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { apiService, UserSession, VerificationResult } from './services/apiService.ts';
import { Institution, Student, AccessAuditLog, UserRole } from './types.ts';
import { Navbar, ScreenId } from './components/Navbar.tsx';
import { DemoModeBar } from './components/DemoModeBar.tsx';
import { StudentAlertToast } from './components/StudentAlertToast.tsx';
import { FrontLandingPage } from './components/screens/FrontLandingPage.tsx';
import { LoginPage } from './components/screens/LoginPage.tsx';
import { StudentPortal } from './components/screens/StudentPortal.tsx';
import { InstitutionDashboard } from './components/screens/InstitutionDashboard.tsx';
import { StudentUploadPage } from './components/screens/StudentUploadPage.tsx';
import { ValidationResultsTable } from './components/screens/ValidationResultsTable.tsx';
import { IntakeMonitoringScreen } from './components/screens/IntakeMonitoringScreen.tsx';
import { AicteCentralDashboard } from './components/screens/AicteCentralDashboard.tsx';
import { VerificationAuditScreen } from './components/screens/VerificationAuditScreen.tsx';
import { ReportsPage } from './components/screens/ReportsPage.tsx';
import { AdminSecurityPage } from './components/screens/AdminSecurityPage.tsx';
import { SAMPLE_BATCH_CSV } from './data/seedData.ts';
import { ShieldAlert } from 'lucide-react';

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserSession | null>(apiService.getCurrentUser());
  // Default entry screen is the Front Landing Page (/)
  const [currentScreen, setCurrentScreen] = useState<ScreenId>('landing');
  const [loginRoleTarget, setLoginRoleTarget] = useState<UserRole>('institution_admin');
  const [selectedInstitutionId, setSelectedInstitutionId] = useState<string>('inst-1');
  const [institutions, setInstitutions] = useState<Institution[]>(apiService.getInstitutions());
  const [students, setStudents] = useState<Student[]>(apiService.getStudents());
  const [auditLogs, setAuditLogs] = useState<AccessAuditLog[]>(apiService.getAuditLogs());
  const [activeAlert, setActiveAlert] = useState<VerificationResult | null>(null);
  const [rbacMessage, setRbacMessage] = useState<string | null>(null);

  // Sync state helper
  const refreshState = () => {
    setInstitutions(apiService.getInstitutions());
    setStudents(apiService.getStudents());
    setAuditLogs(apiService.getAuditLogs());
    setCurrentUser(apiService.getCurrentUser());
  };

  useEffect(() => {
    refreshState();
    // Subscribe to real-time verification alerts
    const unsubscribe = apiService.onAlertDispatched((result) => {
      setActiveAlert(result);
      setAuditLogs(apiService.getAuditLogs());
    });
    return () => unsubscribe();
  }, []);

  // Handle Role Switch from Demo Mode Toolbar
  const handleRoleSwitch = (role: UserRole, targetId?: string) => {
    let session: UserSession;
    if (role === 'student') {
      session = apiService.loginAsStudent(targetId || '123456789012');
      setCurrentScreen('student-portal');
    } else if (role === 'aicte_regulator') {
      session = apiService.login('aicte_regulator');
      setCurrentScreen('aicte-central');
    } else {
      session = apiService.login('institution_admin', targetId || 'inst-1');
      setSelectedInstitutionId(targetId || 'inst-1');
      setCurrentScreen('institution-dashboard');
    }
    setCurrentUser(session);
    setRbacMessage(null);
    refreshState();
  };

  // RBAC Protected Navigation Router
  const handleNavigateWithRBAC = (screen: ScreenId) => {
    setRbacMessage(null);

    // Public routes (Always accessible)
    if (screen === 'landing' || screen === 'verification-audit' || screen === 'admin-security') {
      setCurrentScreen(screen);
      return;
    }

    if (screen === 'login') {
      setCurrentScreen('login');
      return;
    }

    // Role-specific protection checks
    if (screen === 'institution-dashboard' || screen === 'student-upload') {
      if (!currentUser) {
        setLoginRoleTarget('institution_admin');
        setRbacMessage('Authentication Required: Please sign in as an authorized College Administrator.');
        setCurrentScreen('login');
        return;
      }
      if (currentUser.role !== 'institution_admin') {
        setRbacMessage(`Access Denied: Your current persona (${currentUser.role}) does not have Institution Admin privileges.`);
        return;
      }
      setCurrentScreen(screen);
      return;
    }

    if (screen === 'aicte-central') {
      if (!currentUser) {
        setLoginRoleTarget('aicte_regulator');
        setRbacMessage('Authentication Required: Please sign in with AICTE Central Regulatory credentials.');
        setCurrentScreen('login');
        return;
      }
      if (currentUser.role !== 'aicte_regulator') {
        setRbacMessage(`Access Denied: AICTE Central Command is restricted to national regulators. Current persona: ${currentUser.role}`);
        return;
      }
      setCurrentScreen(screen);
      return;
    }

    if (screen === 'student-portal') {
      if (!currentUser) {
        setLoginRoleTarget('student');
        setRbacMessage('Authentication Required: Please sign in with your 12-digit APAAR ID.');
        setCurrentScreen('login');
        return;
      }
      if (currentUser.role !== 'student') {
        // If an institution admin or regulator wants to view student portal, auto-switch persona or allow with Aarav
        apiService.loginAsStudent('123456789012');
        refreshState();
      }
      setCurrentScreen('student-portal');
      return;
    }

    // Default route allowance
    setCurrentScreen(screen);
  };

  // Demo: Simulate Instant Batch Upload
  const handleSimulateUpload = () => {
    const result = apiService.uploadBatch(selectedInstitutionId, SAMPLE_BATCH_CSV);
    refreshState();
    setCurrentScreen('validation-results');
  };

  // Demo: Simulate External Verification & Student SMS Alert
  const handleSimulateVerify = () => {
    const result = apiService.verifyCredential(
      '1234-5678-9012',
      'Tata Consultancy Services (TCS) Campus Verification Desk',
      '14.143.190.45'
    );
    setActiveAlert(result);
    setAuditLogs(apiService.getAuditLogs());
  };

  // Demo: Reset Database back to initial seed
  const handleResetData = () => {
    if (confirm('Reset database back to initial seed data?')) {
      apiService.resetSeedData();
      refreshState();
      setSelectedInstitutionId('inst-1');
    }
  };

  const handleUpdateStudent = (studentId: string, updates: Partial<Student>) => {
    apiService.updateStudent(studentId, updates);
    refreshState();
  };

  const handleDeleteStudent = (studentId: string) => {
    apiService.deleteStudent(studentId);
    refreshState();
  };

  const activeInstitution = institutions.find((i) => i.id === selectedInstitutionId) || institutions[0];
  const activeIntake = activeInstitution ? apiService.getIntakeCheck(activeInstitution.id) : null;

  // Stats for badge alerts
  const duplicateCount = students.filter((s) => s.validation_status === 'Duplicate').length;
  const isAnyBreached = institutions.some((i) => {
    const intake = apiService.getIntakeCheck(i.id);
    return intake.is_exceeded;
  });

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* 1. Global Demo Mode Toolbar */}
      <DemoModeBar
        currentUser={currentUser}
        onRoleSwitch={handleRoleSwitch}
        onNavigateLanding={() => {
          setRbacMessage(null);
          setCurrentScreen('landing');
        }}
        onSimulateUpload={handleSimulateUpload}
        onSimulateVerify={handleSimulateVerify}
        onResetData={handleResetData}
      />

      {/* 2. Main Navigation Bar */}
      <Navbar
        currentScreen={currentScreen}
        onSelectScreen={handleNavigateWithRBAC}
        currentUser={currentUser}
        onLogout={() => {
          apiService.logout();
          setCurrentUser(null);
          setCurrentScreen('landing');
        }}
        stats={{
          duplicateCount,
          intakeBreached: isAnyBreached
        }}
      />

      {/* RBAC Notice / Feedback Toast */}
      {rbacMessage && (
        <div className="max-w-7xl mx-auto px-4 pt-4 w-full">
          <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/40 text-xs text-amber-200 flex items-center justify-between gap-3 animate-in fade-in">
            <div className="flex items-center gap-2.5">
              <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
              <span>{rbacMessage}</span>
            </div>
            <button
              onClick={() => setRbacMessage(null)}
              className="px-2 py-0.5 rounded bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 text-[11px] font-semibold cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      {/* 3. Screen Views Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-6">
        {/* Entry Public Landing Page (/) */}
        {currentScreen === 'landing' && (
          <FrontLandingPage
            onNavigateToLogin={(role) => {
              setLoginRoleTarget(role);
              setCurrentScreen('login');
            }}
            onNavigateToPortal={(role) => {
              handleRoleSwitch(role);
            }}
            onTriggerAlert={(res) => setActiveAlert(res)}
            institutions={institutions}
            students={students}
          />
        )}

        {/* Portal Login Page */}
        {currentScreen === 'login' && (
          <LoginPage
            initialRole={loginRoleTarget}
            onLoginSuccess={(session) => {
              setCurrentUser(session);
              setRbacMessage(null);
              if (session.role === 'aicte_regulator') {
                setCurrentScreen('aicte-central');
              } else if (session.role === 'student') {
                setCurrentScreen('student-portal');
              } else {
                if (session.institution_id) setSelectedInstitutionId(session.institution_id);
                setCurrentScreen('institution-dashboard');
              }
              refreshState();
            }}
            institutions={institutions}
            students={students}
          />
        )}

        {/* Citizen / Student Portal */}
        {currentScreen === 'student-portal' && (
          <StudentPortal
            currentUser={currentUser}
            students={students}
            institutions={institutions}
            auditLogs={auditLogs}
            onSelectStudent={(apaarId) => {
              apiService.loginAsStudent(apaarId);
              refreshState();
            }}
          />
        )}

        {/* Institution Dashboard */}
        {currentScreen === 'institution-dashboard' && activeInstitution && activeIntake && (
          <InstitutionDashboard
            institution={activeInstitution}
            students={students}
            intakeAnalysis={activeIntake}
            onNavigate={handleNavigateWithRBAC}
            institutions={institutions}
            onSelectInstitution={setSelectedInstitutionId}
          />
        )}

        {/* Student Batch Upload */}
        {currentScreen === 'student-upload' && activeInstitution && (
          <StudentUploadPage
            institution={activeInstitution}
            institutions={institutions}
            onSelectInstitution={setSelectedInstitutionId}
            onUploadSuccess={refreshState}
            onNavigate={handleNavigateWithRBAC}
          />
        )}

        {/* Validation Results Table */}
        {currentScreen === 'validation-results' && (
          <ValidationResultsTable
            students={students}
            institutions={institutions}
            onUpdateStudent={handleUpdateStudent}
            onDeleteStudent={handleDeleteStudent}
            selectedInstitutionId={currentUser?.role === 'institution_admin' ? selectedInstitutionId : undefined}
            onSelectInstitution={setSelectedInstitutionId}
          />
        )}

        {/* Intake Monitoring Screen */}
        {currentScreen === 'intake-monitoring' && (
          <IntakeMonitoringScreen
            institutions={institutions}
            students={students}
            selectedInstitutionId={selectedInstitutionId}
            onSelectInstitution={setSelectedInstitutionId}
          />
        )}

        {/* AICTE Central Regulator Dashboard */}
        {currentScreen === 'aicte-central' && (
          <AicteCentralDashboard
            institutions={institutions}
            students={students}
            onNavigate={handleNavigateWithRBAC}
            onSelectInstitution={(id) => {
              setSelectedInstitutionId(id);
            }}
          />
        )}

        {/* Credential Verification & Access Audit */}
        {currentScreen === 'verification-audit' && (
          <VerificationAuditScreen
            students={students}
            auditLogs={auditLogs}
            onTriggerAlert={(res) => setActiveAlert(res)}
          />
        )}

        {/* Compliance Reports & Data Queries */}
        {currentScreen === 'reports' && (
          <ReportsPage
            institutions={institutions}
            students={students}
          />
        )}

        {/* Admin, Security & SQL Seeder Blueprint */}
        {currentScreen === 'admin-security' && (
          <AdminSecurityPage />
        )}
      </main>

      {/* 4. Real-Time Student Access Alert Notification Pop-up */}
      <StudentAlertToast
        alert={activeAlert}
        onClose={() => setActiveAlert(null)}
        onNavigateToAudit={() => setCurrentScreen('verification-audit')}
      />

      {/* 5. Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-400">
              All India Council for Technical Education (AICTE)
            </span>
            <span>•</span>
            <span>Academic Bank of Credits (ABC) & APAAR Registry</span>
          </div>
          <div className="text-[11px] text-slate-500">
            Multi-Role RBAC • Front Entry Landing Page • Citizen Student Portal • Real-Time SMS Alert Ledger
          </div>
        </div>
      </footer>
    </div>
  );
}
