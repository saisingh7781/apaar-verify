/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import { apiService } from './apiService.ts';

test('apiService initializes seed institutions and students', () => {
  apiService.initData(true);
  const institutions = apiService.getInstitutions();
  assert.equal(institutions.length, 3);
  assert.equal(institutions[0].aicte_id, 'AICTE-TN-042');
  assert.equal(institutions[2].approved_intake, 90);

  const students = apiService.getStudents();
  assert.ok(students.length >= 20);
});

test('apiService detects capacity breach in PSG College (95 > 90)', () => {
  apiService.initData(true);
  const psgIntake = apiService.getIntakeCheck('inst-3');
  assert.equal(psgIntake.approved_intake, 90);
  assert.equal(psgIntake.enrolled_count, 95);
  assert.equal(psgIntake.is_exceeded, true);
  assert.equal(psgIntake.excess_count, 5);
  assert.ok(psgIntake.utilization_percentage > 100);
});

test('apiService verifyCredential inserts audit log and triggers student alert', () => {
  apiService.initData(true);
  const initialLogsCount = apiService.getAuditLogs().length;

  let alertDispatched = false;
  const unsubscribe = apiService.onAlertDispatched((res) => {
    if (res.student?.apaar_id === '123456789012') {
      alertDispatched = true;
    }
  });

  const result = apiService.verifyCredential('1234-5678-9012', 'Infosys Tech Recruitment');
  assert.equal(result.verified, true);
  assert.equal(result.student?.full_name, 'Aarav Ramanathan');
  assert.match(result.smsMessage, /Alert: Your APAAR academic record was accessed by Infosys Tech Recruitment/);

  const updatedLogs = apiService.getAuditLogs();
  assert.equal(updatedLogs.length, initialLogsCount + 1);
  assert.equal(updatedLogs[0].apaar_id, '123456789012');
  assert.equal(updatedLogs[0].alert_dispatched, true);

  unsubscribe();
});

test('apiService supports student login and consent control lock', () => {
  apiService.initData(true);
  const session = apiService.loginAsStudent('123456789012');
  assert.equal(session.role, 'student');
  assert.equal(session.student_apaar_id, '123456789012');
  assert.equal(session.name, 'Aarav Ramanathan');

  // Lock consent
  apiService.toggleStudentConsent('123456789012', true);
  const lockedVerify = apiService.verifyCredential('1234-5678-9012', 'ThirdParty Background Check Agency');
  assert.equal(lockedVerify.verified, false);
  assert.equal(lockedVerify.isLocked, true);
  assert.match(lockedVerify.smsMessage, /BLOCKED on/);

  // Unlock consent
  apiService.toggleStudentConsent('123456789012', false);
  const unlockedVerify = apiService.verifyCredential('1234-5678-9012', 'ThirdParty Background Check Agency');
  assert.equal(unlockedVerify.verified, true);
  assert.equal(unlockedVerify.isLocked, false);
});

