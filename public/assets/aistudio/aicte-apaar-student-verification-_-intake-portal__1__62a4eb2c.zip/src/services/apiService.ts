/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Institution, Student, AccessAuditLog, IntakeAnalysis, ValidationStatus, AdmissionCategory, UserRole } from '../types.ts';
import { INITIAL_INSTITUTIONS, INITIAL_STUDENTS, INITIAL_AUDIT_LOGS } from '../data/seedData.ts';
import { evaluateStudentRecord, calculateIntakeAnalysis, normalizeApaarId, parseCSVToStudents } from '../utils/validation.ts';

const STORAGE_KEY_INSTITUTIONS = 'aicte_apaar_institutions_v1';
const STORAGE_KEY_STUDENTS = 'aicte_apaar_students_v1';
const STORAGE_KEY_AUDIT_LOGS = 'aicte_apaar_audit_logs_v1';
const STORAGE_KEY_AUTH = 'aicte_apaar_auth_v1';

export interface UserSession {
  role: UserRole;
  institution_id?: string;
  student_apaar_id?: string;
  name: string;
  email: string;
  token: string;
}

export interface VerificationResult {
  verified: boolean;
  isLocked?: boolean;
  lockNotice?: string;
  student?: Student;
  institution?: Institution;
  auditLog: AccessAuditLog;
  smsMessage: string;
}

type AlertListener = (result: VerificationResult) => void;

class ApiService {
  private institutions: Institution[] = [];
  private students: Student[] = [];
  private auditLogs: AccessAuditLog[] = [];
  private alertListeners: Set<AlertListener> = new Set();
  private currentUser: UserSession | null = null;

  constructor() {
    this.initData();
  }

  public initData(forceReset = false) {
    if (!forceReset && typeof window !== 'undefined') {
      try {
        const storedInst = localStorage.getItem(STORAGE_KEY_INSTITUTIONS);
        const storedStud = localStorage.getItem(STORAGE_KEY_STUDENTS);
        const storedLogs = localStorage.getItem(STORAGE_KEY_AUDIT_LOGS);
        const storedAuth = localStorage.getItem(STORAGE_KEY_AUTH);

        if (storedInst && storedStud) {
          this.institutions = JSON.parse(storedInst);
          this.students = JSON.parse(storedStud);
          this.auditLogs = storedLogs ? JSON.parse(storedLogs) : [...INITIAL_AUDIT_LOGS];
          this.currentUser = storedAuth ? JSON.parse(storedAuth) : null;
          return;
        }
      } catch (err) {
        console.warn('Failed to load from localStorage, initializing defaults', err);
      }
    }

    // Default initialization
    this.institutions = JSON.parse(JSON.stringify(INITIAL_INSTITUTIONS));
    this.students = JSON.parse(JSON.stringify(INITIAL_STUDENTS));
    this.auditLogs = JSON.parse(JSON.stringify(INITIAL_AUDIT_LOGS));
    this.currentUser = {
      role: 'institution_admin',
      institution_id: 'inst-1',
      name: 'Dr. R. Raman (Registrar)',
      email: 'registrar@mitindia.edu',
      token: 'jwt_mock_mit_admin_token'
    };
    this.saveData();
  }

  private saveData() {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_KEY_INSTITUTIONS, JSON.stringify(this.institutions));
      localStorage.setItem(STORAGE_KEY_STUDENTS, JSON.stringify(this.students));
      localStorage.setItem(STORAGE_KEY_AUDIT_LOGS, JSON.stringify(this.auditLogs));
      if (this.currentUser) {
        localStorage.setItem(STORAGE_KEY_AUTH, JSON.stringify(this.currentUser));
      } else {
        localStorage.removeItem(STORAGE_KEY_AUTH);
      }
    } catch (err) {
      console.error('Error saving to localStorage', err);
    }
  }

  public onAlertDispatched(listener: AlertListener) {
    this.alertListeners.add(listener);
    return () => this.alertListeners.delete(listener);
  }

  // --- Auth API ---
  public login(role: UserRole, institutionId?: string, email?: string): UserSession {
    if (role === 'student') {
      const student = this.students[0];
      return this.loginAsStudent(student.apaar_id);
    }

    const institution = institutionId 
      ? this.institutions.find(i => i.id === institutionId) 
      : this.institutions[0];

    const session: UserSession = {
      role,
      institution_id: role === 'institution_admin' ? (institution?.id || 'inst-1') : undefined,
      name: role === 'institution_admin' ? `Registrar (${institution?.name.split(',')[0] || 'MIT'})` : 'Prof. A. Sahasrabudhe (AICTE Officer)',
      email: email || (role === 'institution_admin' ? 'admin@institution.edu.in' : 'regulator@aicte-india.org'),
      token: `bearer_${role}_${Date.now()}`
    };

    this.currentUser = session;
    this.saveData();
    return session;
  }

  public loginAsStudent(apaarId: string): UserSession {
    const clean = normalizeApaarId(apaarId);
    const student = this.students.find(s => normalizeApaarId(s.apaar_id) === clean) || this.students[0];
    const session: UserSession = {
      role: 'student',
      student_apaar_id: student.apaar_id,
      institution_id: student.institution_id,
      name: student.full_name,
      email: `${student.student_id.toLowerCase().replace(/[^a-z0-9]/g, '')}@student.ac.in`,
      token: `bearer_student_${Date.now()}`
    };
    this.currentUser = session;
    this.saveData();
    return session;
  }

  public toggleStudentConsent(apaarId: string, isLocked: boolean): boolean {
    const clean = normalizeApaarId(apaarId);
    const student = this.students.find(s => normalizeApaarId(s.apaar_id) === clean);
    if (!student) return false;
    student.is_sharing_locked = isLocked;
    this.saveData();
    return true;
  }

  public getCurrentUser(): UserSession | null {
    return this.currentUser;
  }

  public logout() {
    this.currentUser = null;
    this.saveData();
  }

  // --- Institutions API ---
  public getInstitutions(): Institution[] {
    return [...this.institutions];
  }

  public getInstitutionById(id: string): Institution | undefined {
    return this.institutions.find(i => i.id === id);
  }

  // --- Students API ---
  public getStudents(institutionId?: string): Student[] {
    if (institutionId) {
      return this.students.filter(s => s.institution_id === institutionId);
    }
    return [...this.students];
  }

  public getStudentByApaar(apaarId: string): Student | undefined {
    const clean = normalizeApaarId(apaarId);
    return this.students.find(s => normalizeApaarId(s.apaar_id) === clean);
  }

  public updateStudent(studentId: string, updates: Partial<Student>): Student {
    const index = this.students.findIndex(s => s.id === studentId);
    if (index === -1) {
      throw new Error(`Student ${studentId} not found`);
    }

    const current = this.students[index];
    const updated: Student = { ...current, ...updates };

    // Re-evaluate validation status
    const evalResult = evaluateStudentRecord(updated, this.students, []);
    updated.validation_status = evalResult.status;
    updated.validation_notes = evalResult.notes;

    this.students[index] = updated;
    this.saveData();
    return updated;
  }

  public deleteStudent(studentId: string): boolean {
    const initialLen = this.students.length;
    this.students = this.students.filter(s => s.id !== studentId);
    if (this.students.length !== initialLen) {
      this.saveData();
      return true;
    }
    return false;
  }

  // --- Batch Upload API: POST /api/v1/students/upload-batch ---
  public uploadBatch(
    institutionId: string,
    csvContent: string
  ): { total: number; valid: number; warnings: number; duplicates: number; newStudents: Student[] } {
    const parsed = parseCSVToStudents(csvContent);
    const institution = this.getInstitutionById(institutionId);
    if (!institution) throw new Error('Institution not found');

    const addedStudents: Student[] = [];
    let validCount = 0;
    let warningCount = 0;
    let dupCount = 0;

    for (let i = 0; i < parsed.records.length; i++) {
      const rec = parsed.records[i];
      const partialStudent: Partial<Student> = {
        apaar_id: rec.apaar_id,
        student_id: rec.student_id,
        full_name: rec.full_name,
        program: rec.program,
        admission_year: rec.admission_year,
        admission_category: rec.admission_category,
        institution_id: institutionId
      };

      const evalResult = evaluateStudentRecord(partialStudent, this.students, parsed.records as any);

      if (evalResult.status === 'Valid') validCount++;
      else if (evalResult.status === 'Duplicate') dupCount++;
      else warningCount++;

      const newStudent: Student = {
        id: `stud-up-${Date.now()}-${i}`,
        apaar_id: normalizeApaarId(rec.apaar_id),
        student_id: rec.student_id,
        full_name: rec.full_name,
        program: rec.program,
        admission_year: rec.admission_year,
        admission_category: rec.admission_category,
        institution_id: institutionId,
        validation_status: evalResult.status,
        validation_notes: evalResult.notes,
        created_at: new Date().toISOString(),
        contact_masked: `+91 9${Math.floor(10 + Math.random() * 89)}*** **${Math.floor(100 + Math.random() * 899)}`
      };

      addedStudents.push(newStudent);
    }

    // Append to student registry
    this.students = [...addedStudents, ...this.students];
    this.saveData();

    return {
      total: addedStudents.length,
      valid: validCount,
      warnings: warningCount,
      duplicates: dupCount,
      newStudents: addedStudents
    };
  }

  // --- Monitoring Intake Check API: GET /api/v1/monitoring/intake-check/{institution_id} ---
  public getIntakeCheck(institutionId: string): IntakeAnalysis {
    const institution = this.getInstitutionById(institutionId);
    if (!institution) {
      throw new Error(`Institution not found: ${institutionId}`);
    }
    return calculateIntakeAnalysis(institution, this.students);
  }

  public getAllIntakeAnalyses(): IntakeAnalysis[] {
    return this.institutions.map(inst => calculateIntakeAnalysis(inst, this.students));
  }

  // --- Verification API: POST /api/v1/verify/credential ---
  public verifyCredential(
    apaarId: string,
    verifierEntity: string,
    ipAddress = '14.143.190.45'
  ): VerificationResult {
    const cleanApaar = normalizeApaarId(apaarId);
    const student = this.students.find(s => normalizeApaarId(s.apaar_id) === cleanApaar);
    const institution = student ? this.getInstitutionById(student.institution_id) : undefined;
    const isLocked = Boolean(student?.is_sharing_locked);

    const now = new Date();
    const timestampStr = now.toISOString().replace('T', ' ').slice(0, 19) + ' UTC';

    const logEntry: AccessAuditLog = {
      log_id: `log-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      apaar_id: cleanApaar || apaarId,
      verifier_entity: verifierEntity || 'Authorized Third-Party Verifier',
      access_timestamp: timestampStr,
      ip_address: ipAddress,
      alert_dispatched: true,
      student_name: student?.full_name || 'Unregistered Candidate',
      institution_name: institution?.name || 'Unknown Institution'
    };

    // Prepend to audit logs
    this.auditLogs = [logEntry, ...this.auditLogs];
    this.saveData();

    // Required Notification Template:
    // If student locked sharing:
    // "Security Alert: An access attempt by [Verifier] was BLOCKED on [Timestamp] because your APAAR credential sharing is LOCKED by you."
    // If unlocked:
    // "Alert: Your APAAR academic record was accessed by [Verifier Name] on [Timestamp]. If this wasn't you, report it immediately to AICTE support."
    const smsMessage = isLocked
      ? `Security Alert: An access attempt by ${logEntry.verifier_entity} was BLOCKED on ${timestampStr} because your APAAR credential sharing is LOCKED by you.`
      : `Alert: Your APAAR academic record was accessed by ${logEntry.verifier_entity} on ${timestampStr}. If this wasn't you, report it immediately to AICTE support.`;

    const result: VerificationResult = {
      verified: !isLocked && !!student,
      isLocked,
      lockNotice: isLocked ? 'Access blocked: Student has locked third-party verification consent.' : undefined,
      student: isLocked ? undefined : student,
      institution: isLocked ? undefined : institution,
      auditLog: logEntry,
      smsMessage
    };

    // Asynchronously dispatch real-time student alert
    setTimeout(() => {
      this.alertListeners.forEach(listener => listener(result));
    }, 150);

    return result;
  }

  // --- Audit Logs API ---
  public getAuditLogs(): AccessAuditLog[] {
    return [...this.auditLogs];
  }

  // Reset database back to original initial seed state
  public resetSeedData() {
    this.initData(true);
  }
}

export const apiService = new ApiService();
