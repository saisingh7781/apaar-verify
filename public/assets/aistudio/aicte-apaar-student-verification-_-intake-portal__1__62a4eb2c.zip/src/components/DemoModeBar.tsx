/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Sparkles, Shield, Building2, UserCheck, UploadCloud, QrCode, RotateCcw, Home } from 'lucide-react';
import { UserSession } from '../services/apiService.ts';
import { UserRole } from '../types.ts';

interface DemoModeBarProps {
  currentUser: UserSession | null;
  onRoleSwitch: (role: UserRole, targetId?: string) => void;
  onNavigateLanding: () => void;
  onSimulateUpload: () => void;
  onSimulateVerify: () => void;
  onResetData: () => void;
}

export const DemoModeBar: React.FC<DemoModeBarProps> = ({
  currentUser,
  onRoleSwitch,
  onNavigateLanding,
  onSimulateUpload,
  onSimulateVerify,
  onResetData
}) => {
  const getPersonaLabel = () => {
    if (!currentUser) return 'Public Visitor / Anonymous';
    if (currentUser.role === 'aicte_regulator') return 'AICTE Central Regulator';
    if (currentUser.role === 'student') return `Citizen / Student (${currentUser.name.split(' ')[0]})`;
    return 'Institution Admin (MIT Chennai)';
  };

  return (
    <header className="bg-slate-900 text-slate-100 border-b border-slate-800 text-xs shadow-md">
      {/* Tricolor Government Strip */}
      <div className="h-1 w-full bg-gradient-to-r from-orange-500 via-white to-emerald-600" />

      <div className="max-w-7xl mx-auto px-4 py-2 flex flex-wrap items-center justify-between gap-2.5">
        {/* Left: Presentation Demo Mode Badge & Active Persona */}
        <div className="flex items-center gap-2">
          <span className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-semibold tracking-wide border border-amber-500/30">
            <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
            PRESENTATION DEMO TOOLBAR
          </span>
          <span className="hidden lg:inline text-slate-400">
            Active: <strong className="text-white">{getPersonaLabel()}</strong>
          </span>
        </div>

        {/* Center / Right: Quick Demo Actions & Role Switchers */}
        <div className="flex flex-wrap items-center gap-1.5">
          {/* Public Home */}
          <button
            onClick={onNavigateLanding}
            className="flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-medium transition cursor-pointer"
            title="Public Front Landing Page"
          >
            <Home className="w-3.5 h-3.5 text-slate-400" />
            <span>Public Home</span>
          </button>

          {/* 3 One-Click Role Switchers */}
          <button
            onClick={() => onRoleSwitch('institution_admin', 'inst-1')}
            className={`flex items-center gap-1 px-2 py-1 rounded font-medium transition cursor-pointer ${
              currentUser?.role === 'institution_admin'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-slate-800/80 hover:bg-slate-800 text-indigo-300 border border-slate-700'
            }`}
            title="Log in as MIT Registrar"
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>Admin (MIT)</span>
          </button>

          <button
            onClick={() => onRoleSwitch('aicte_regulator')}
            className={`flex items-center gap-1 px-2 py-1 rounded font-medium transition cursor-pointer ${
              currentUser?.role === 'aicte_regulator'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-slate-800/80 hover:bg-slate-800 text-emerald-300 border border-slate-700'
            }`}
            title="Log in as AICTE Central Regulator"
          >
            <Shield className="w-3.5 h-3.5" />
            <span>Regulator</span>
          </button>

          <button
            onClick={() => onRoleSwitch('student', '123456789012')}
            className={`flex items-center gap-1 px-2 py-1 rounded font-medium transition cursor-pointer ${
              currentUser?.role === 'student'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'bg-slate-800/80 hover:bg-slate-800 text-amber-300 border border-slate-700'
            }`}
            title="Log in as Student Aarav Ramanathan"
          >
            <UserCheck className="w-3.5 h-3.5" />
            <span>Student (Aarav)</span>
          </button>

          {/* Simulators */}
          <button
            onClick={onSimulateUpload}
            className="flex items-center gap-1 px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-sky-300 border border-slate-700 font-medium transition cursor-pointer"
            title="Simulate instant CSV batch upload with duplicates"
          >
            <UploadCloud className="w-3.5 h-3.5 text-sky-400" />
            <span>Load Batch</span>
          </button>

          <button
            onClick={onSimulateVerify}
            className="flex items-center gap-1 px-2.5 py-1 rounded bg-amber-600 hover:bg-amber-500 text-white font-medium transition cursor-pointer shadow-xs"
            title="Simulate TCS verification and real-time student SMS alert"
          >
            <QrCode className="w-3.5 h-3.5" />
            <span>Simulate Verify</span>
          </button>

          {/* Reset */}
          <button
            onClick={onResetData}
            className="flex items-center gap-1 px-2 py-1 rounded hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition cursor-pointer"
            title="Reset database to initial seed state"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </header>
  );
};
