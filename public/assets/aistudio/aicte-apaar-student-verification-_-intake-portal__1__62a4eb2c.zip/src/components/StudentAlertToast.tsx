/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Smartphone, Bell, X, ShieldAlert, CheckCircle2, Building, ExternalLink } from 'lucide-react';
import { VerificationResult } from '../services/apiService.ts';

interface StudentAlertToastProps {
  alert: VerificationResult | null;
  onClose: () => void;
  onNavigateToAudit?: () => void;
}

export const StudentAlertToast: React.FC<StudentAlertToastProps> = ({
  alert,
  onClose,
  onNavigateToAudit
}) => {
  if (!alert) return null;

  return (
    <div
      role="dialog"
      aria-labelledby="alert-dialog-title"
      aria-modal="true"
      className="fixed bottom-4 right-4 left-4 sm:left-auto sm:right-5 sm:bottom-5 z-50 max-w-md w-auto sm:w-full bg-slate-900 border-2 border-amber-500/80 rounded-2xl shadow-2xl text-slate-100 overflow-hidden animate-in fade-in slide-in-from-bottom-5 duration-300"
    >
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-amber-600 to-orange-600 px-4 py-2.5 flex items-center justify-between text-white">
        <div className="flex items-center gap-2 font-semibold text-sm">
          <Smartphone className="w-4 h-4 animate-bounce" />
          <span id="alert-dialog-title">Live Student SMS Alert Dispatched</span>
        </div>
        <button
          onClick={onClose}
          className="text-white/80 hover:text-white p-1 rounded-full hover:bg-black/20 transition cursor-pointer"
          aria-label="Close notification"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="p-4 space-y-3">
        {/* Recipient Details */}
        <div className="flex items-center justify-between text-xs bg-slate-800/80 px-3 py-2 rounded-lg border border-slate-700/60">
          <div>
            <span className="text-slate-400 block">Registered Student:</span>
            <span className="font-semibold text-white">{alert.student?.full_name || 'Candidate'}</span>
          </div>
          <div className="text-right">
            <span className="text-slate-400 block">Mobile:</span>
            <span className="font-mono text-amber-300 font-semibold">{alert.student?.contact_masked || '+91 98*** **412'}</span>
          </div>
        </div>

        {/* Realistic SMS Message Bubble */}
        <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 relative">
          <div className="flex items-center gap-2 mb-2">
            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              SMS Gateway: VM-AICTE-GOV
            </span>
            <span className="text-[10px] text-slate-400">{alert.auditLog.access_timestamp.slice(11)}</span>
          </div>
          <p className="text-xs text-slate-200 leading-relaxed font-sans bg-slate-900/90 p-2.5 rounded-lg border-l-4 border-amber-500">
            "{alert.smsMessage}"
          </p>
        </div>

        {/* Verification Metadata */}
        <div className="text-[11px] text-slate-400 space-y-1 bg-slate-800/40 p-2.5 rounded-lg border border-slate-800">
          <div className="flex justify-between">
            <span>Querying Verifier:</span>
            <strong className="text-slate-200">{alert.auditLog.verifier_entity}</strong>
          </div>
          <div className="flex justify-between">
            <span>APAAR ID Queried:</span>
            <strong className="text-amber-400 font-mono">{alert.auditLog.apaar_id}</strong>
          </div>
          <div className="flex justify-between">
            <span>Client IP Address:</span>
            <strong className="text-slate-300 font-mono">{alert.auditLog.ip_address}</strong>
          </div>
          <div className="flex justify-between">
            <span>PostgreSQL Ledger Status:</span>
            <span className="text-emerald-400 font-medium inline-flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" /> Logged & Alert Dispatched
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2 pt-1">
          {onNavigateToAudit && (
            <button
              onClick={() => {
                onClose();
                onNavigateToAudit();
              }}
              className="flex-1 py-1.5 px-3 bg-amber-600 hover:bg-amber-500 text-white text-xs font-medium rounded-lg transition flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              View in Audit Ledger
            </button>
          )}
          <button
            onClick={onClose}
            className="py-1.5 px-4 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium rounded-lg transition border border-slate-700 cursor-pointer"
          >
            Acknowledge
          </button>
        </div>
      </div>
    </div>
  );
};
