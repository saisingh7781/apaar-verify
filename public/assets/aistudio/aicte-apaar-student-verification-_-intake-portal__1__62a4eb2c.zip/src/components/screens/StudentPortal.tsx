/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  UserCheck,
  Shield,
  Smartphone,
  Lock,
  Unlock,
  QrCode,
  History,
  GraduationCap,
  Building,
  CheckCircle2,
  AlertTriangle,
  Download,
  Calendar,
  Layers,
  Sparkles,
  ExternalLink,
  ShieldCheck,
  CreditCard
} from 'lucide-react';
import { Student, Institution, AccessAuditLog } from '../../types.ts';
import { apiService, UserSession } from '../../services/apiService.ts';
import { isValidApaarId } from '../../utils/validation.ts';

interface StudentPortalProps {
  currentUser: UserSession | null;
  students: Student[];
  institutions: Institution[];
  auditLogs: AccessAuditLog[];
  onSelectStudent?: (apaarId: string) => void;
}

export const StudentPortal: React.FC<StudentPortalProps> = ({
  currentUser,
  students,
  institutions,
  auditLogs,
  onSelectStudent
}) => {
  // Find current student by session apaar id or default to Aarav Ramanathan
  const activeStudent =
    students.find((s) => s.apaar_id === currentUser?.student_apaar_id) ||
    students[0];

  const [activeTab, setActiveTab] = useState<'profile' | 'audit' | 'consent'>('profile');
  const [isLocked, setIsLocked] = useState<boolean>(Boolean(activeStudent.is_sharing_locked));
  const [consentUpdated, setConsentUpdated] = useState(false);

  const institution = institutions.find((i) => i.id === activeStudent.institution_id);

  // Filter audit logs specifically for this student
  const studentLogs = auditLogs.filter(
    (log) => log.apaar_id.replace(/[\s-]/g, '') === activeStudent.apaar_id.replace(/[\s-]/g, '')
  );

  const handleToggleConsent = () => {
    const nextState = !isLocked;
    setIsLocked(nextState);
    apiService.toggleStudentConsent(activeStudent.apaar_id, nextState);
    setConsentUpdated(true);
    setTimeout(() => setConsentUpdated(false), 2500);
  };

  const handlePrintCard = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* 1. Header & Identity Ribbon */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-md flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-600 p-0.5 shadow-lg">
            <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center text-amber-400 font-bold text-lg">
              {activeStudent.full_name
                .split(' ')
                .map((n) => n[0])
                .slice(0, 2)
                .join('')}
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-amber-500/10 text-amber-300 border border-amber-500/20">
                Citizen / Student Portal
              </span>
              <span className="text-xs text-slate-400">DigiLocker & ABC Verified</span>
            </div>
            <h1 className="text-xl font-bold text-white mt-1">
              {activeStudent.full_name}
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              Roll No: <strong className="text-slate-200 font-mono">{activeStudent.student_id}</strong> •{' '}
              {institution?.name.split(',')[0]}
            </p>
          </div>
        </div>

        {/* Quick Student Switcher for Presentations */}
        <div className="flex items-center gap-2 text-xs">
          <span className="text-slate-400 font-medium hidden sm:inline">Active Student:</span>
          <select
            value={activeStudent.apaar_id}
            onChange={(e) => {
              if (onSelectStudent) onSelectStudent(e.target.value);
              else apiService.loginAsStudent(e.target.value);
            }}
            className="px-3 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-white text-xs cursor-pointer focus:outline-hidden"
          >
            {students.slice(0, 6).map((s) => (
              <option key={s.id} value={s.apaar_id}>
                {s.full_name} ({s.validation_status})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* 2. Navigation Tabs */}
      <div className="flex gap-2 border-b border-slate-800 pb-2 text-xs">
        <button
          onClick={() => setActiveTab('profile')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl font-semibold transition cursor-pointer ${
            activeTab === 'profile'
              ? 'bg-amber-600 text-white shadow-md'
              : 'bg-slate-900 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
          }`}
        >
          <CreditCard className="w-4 h-4" />
          <span>My Academic Profile & APAAR Card</span>
        </button>

        <button
          onClick={() => setActiveTab('audit')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl font-semibold transition cursor-pointer relative ${
            activeTab === 'audit'
              ? 'bg-amber-600 text-white shadow-md'
              : 'bg-slate-900 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
          }`}
        >
          <History className="w-4 h-4" />
          <span>Live Access Audit Trail</span>
          {studentLogs.length > 0 && (
            <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-amber-500/20 text-amber-300 font-bold">
              {studentLogs.length} Events
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('consent')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl font-semibold transition cursor-pointer ${
            activeTab === 'consent'
              ? 'bg-amber-600 text-white shadow-md'
              : 'bg-slate-900 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
          }`}
        >
          {isLocked ? <Lock className="w-4 h-4 text-rose-300" /> : <Unlock className="w-4 h-4 text-emerald-300" />}
          <span>Privacy & Consent Lock</span>
          {isLocked && (
            <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-rose-500/20 text-rose-300 font-bold">
              LOCKED
            </span>
          )}
        </button>
      </div>

      {/* 3. Tab 1: My Academic Profile & Digital APAAR Card */}
      {activeTab === 'profile' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Digital APAAR Identity Card */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-amber-950/30 border-2 border-amber-500/50 rounded-3xl p-6 shadow-2xl relative overflow-hidden space-y-5">
              {/* Card Tricolor Header */}
              <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-orange-500 via-white to-emerald-500" />

              <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
                    <GraduationCap className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] font-extrabold uppercase tracking-widest text-amber-400 block">
                      GOVERNMENT OF INDIA
                    </span>
                    <span className="text-xs font-bold text-white">
                      AICTE • ABC • APAAR CARD
                    </span>
                  </div>
                </div>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  e-KYC VERIFIED
                </span>
              </div>

              {/* Card Body */}
              <div className="flex items-start gap-4">
                {/* Photo & QR */}
                <div className="space-y-2 shrink-0">
                  <div className="w-24 h-28 bg-slate-950 border border-slate-800 rounded-xl flex flex-col items-center justify-center p-2 text-center">
                    <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-xs font-bold text-amber-300">
                      PHOTO
                    </div>
                    <span className="text-[9px] text-slate-500 mt-1 font-mono">DigiLocker</span>
                  </div>
                  <div className="w-24 h-12 bg-white rounded-lg p-1 flex items-center justify-center">
                    <QrCode className="w-10 h-10 text-black" />
                  </div>
                </div>

                {/* Identity Text */}
                <div className="space-y-2 text-xs flex-1">
                  <div>
                    <span className="text-[10px] text-slate-400 block">Student Name</span>
                    <span className="text-sm font-extrabold text-white">{activeStudent.full_name}</span>
                  </div>

                  <div>
                    <span className="text-[10px] text-slate-400 block">National APAAR ID</span>
                    <span className="font-mono text-amber-300 font-extrabold text-xs tracking-wider">
                      {isValidApaarId(activeStudent.apaar_id).formatted || activeStudent.apaar_id}
                    </span>
                  </div>

                  <div>
                    <span className="text-[10px] text-slate-400 block">Degree Program</span>
                    <span className="text-slate-200 font-medium leading-tight block">
                      {activeStudent.program}
                    </span>
                  </div>

                  <div>
                    <span className="text-[10px] text-slate-400 block">Affiliated Institution</span>
                    <span className="text-slate-300 font-medium text-[11px] block">
                      {institution?.name}
                    </span>
                  </div>
                </div>
              </div>

              {/* Card Footer */}
              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-400">
                <span>Batch: {activeStudent.admission_year}</span>
                <span>Category: {activeStudent.admission_category}</span>
                <span className="text-emerald-400 font-semibold">Status: {activeStudent.validation_status}</span>
              </div>
            </div>

            <button
              onClick={handlePrintCard}
              className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download / Print APAAR Digital Card</span>
            </button>
          </div>

          {/* Right Column: Academic Details & ABC Bank */}
          <div className="lg:col-span-7 space-y-4">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-md space-y-4">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <Layers className="w-4 h-4 text-amber-400" />
                Verified Academic Mapping & Enrollment Registry
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="p-3.5 bg-slate-950 rounded-2xl border border-slate-800 space-y-1">
                  <span className="text-slate-400 text-[11px] block">National Student ID (APAAR)</span>
                  <span className="font-mono text-amber-300 font-bold text-sm">
                    {isValidApaarId(activeStudent.apaar_id).formatted}
                  </span>
                  <span className="text-[10px] text-emerald-400 block">Linked to Aadhaar & ABC</span>
                </div>

                <div className="p-3.5 bg-slate-950 rounded-2xl border border-slate-800 space-y-1">
                  <span className="text-slate-400 text-[11px] block">College Roll Number</span>
                  <span className="font-mono text-white font-bold text-sm">{activeStudent.student_id}</span>
                  <span className="text-[10px] text-slate-500 block">Internal institutional identifier</span>
                </div>

                <div className="p-3.5 bg-slate-950 rounded-2xl border border-slate-800 space-y-1 sm:col-span-2">
                  <span className="text-slate-400 text-[11px] block">Enrolled Program & Discipline</span>
                  <span className="text-white font-semibold text-sm">{activeStudent.program}</span>
                  <span className="text-[11px] text-slate-400 block">
                    {institution?.name} ({institution?.aicte_id})
                  </span>
                </div>

                <div className="p-3.5 bg-slate-950 rounded-2xl border border-slate-800 space-y-1">
                  <span className="text-slate-400 text-[11px] block">Admission Quota</span>
                  <span className="text-white font-semibold">{activeStudent.admission_category}</span>
                  <span className="text-[10px] text-slate-500 block">Sanctioned Quota Allocation</span>
                </div>

                <div className="p-3.5 bg-slate-950 rounded-2xl border border-slate-800 space-y-1">
                  <span className="text-slate-400 text-[11px] block">Validation Status</span>
                  <span
                    className={`font-semibold inline-flex items-center gap-1 ${
                      activeStudent.validation_status === 'Valid'
                        ? 'text-emerald-400'
                        : activeStudent.validation_status === 'Duplicate'
                        ? 'text-rose-400'
                        : 'text-amber-400'
                    }`}
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    {activeStudent.validation_status}
                  </span>
                  <span className="text-[10px] text-slate-500 block">
                    {activeStudent.validation_notes || 'Clean record'}
                  </span>
                </div>
              </div>
            </div>

            {/* Academic Bank of Credits (ABC) Mini Card */}
            <div className="p-5 bg-gradient-to-r from-indigo-950/60 to-slate-900 border border-indigo-500/30 rounded-3xl space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <h4 className="font-bold text-xs text-white">
                    Academic Bank of Credits (ABC) Credit Ledger
                  </h4>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-500/20 text-indigo-300">
                  Credits Synced: 48 / 160
                </span>
              </div>
              <p className="text-xs text-slate-300">
                Your earned course credits automatically transfer across recognized universities under the National Credit Framework (NCrF).
              </p>
            </div>
          </div>
        </div>
      )}

      {/* 4. Tab 2: Live Access Audit Trail */}
      {activeTab === 'audit' && (
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl shadow-md space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h3 className="font-bold text-sm text-white flex items-center gap-2">
                  <History className="w-4 h-4 text-amber-400" />
                  Personal Credential Access Log & Real-Time Alert Ledger
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Every time an employer, government portal, or agency verifies your credentials, a permanent entry is stamped below and an SMS is sent to your phone.
                </p>
              </div>
              <span className="px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-mono">
                {studentLogs.length} Access Lookups
              </span>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-lg">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
                  <tr>
                    <th className="py-3 px-4">Access Timestamp</th>
                    <th className="py-3 px-4">Verifier / Organization</th>
                    <th className="py-3 px-4">Client IP Address</th>
                    <th className="py-3 px-4">Alert Dispatched</th>
                    <th className="py-3 px-4 text-right">Student Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-sans">
                  {studentLogs.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-8 text-center text-slate-500 text-xs">
                        No external access lookups recorded for your APAAR ID yet.
                      </td>
                    </tr>
                  ) : (
                    studentLogs.map((log) => (
                      <tr key={log.log_id} className="hover:bg-slate-800/40">
                        <td className="py-3 px-4 font-mono text-slate-300 whitespace-nowrap">
                          {log.access_timestamp}
                        </td>
                        <td className="py-3 px-4 font-semibold text-white">
                          {log.verifier_entity}
                        </td>
                        <td className="py-3 px-4 font-mono text-slate-400">
                          {log.ip_address}
                        </td>
                        <td className="py-3 px-4">
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                            <Smartphone className="w-3 h-3" /> SMS Dispatched
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right">
                          <button
                            onClick={() => {
                              alert(
                                `Flagged Inquiry: Report filed for query by "${log.verifier_entity}" on ${log.access_timestamp}. AICTE Privacy Nodal Officer notified.`
                              );
                            }}
                            className="text-xs text-rose-400 hover:text-rose-300 font-medium transition cursor-pointer"
                          >
                            Report Unauthorized
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 5. Tab 3: Consent & Privacy Lock */}
      {activeTab === 'consent' && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl space-y-6 max-w-3xl">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div>
              <h3 className="font-bold text-base text-white flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-indigo-400" />
                Student Sovereign Consent & Credential Privacy Control
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Under AICTE and Digital Personal Data Protection (DPDP) Act rules, you maintain unconditional authority to lock your credential verification.
              </p>
            </div>
          </div>

          {consentUpdated && (
            <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-xs text-emerald-300 flex items-center gap-2 animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Consent lock state updated successfully in the national registry!</span>
            </div>
          )}

          {/* Big Consent Toggle Box */}
          <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800 flex flex-wrap items-center justify-between gap-6">
            <div className="space-y-1 max-w-md">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block">
                Verification Sharing Status
              </span>
              <h4 className="text-lg font-bold text-white flex items-center gap-2">
                {isLocked ? (
                  <>
                    <Lock className="w-5 h-5 text-rose-400" />
                    <span className="text-rose-400">Credential Sharing is LOCKED</span>
                  </>
                ) : (
                  <>
                    <Unlock className="w-5 h-5 text-emerald-400" />
                    <span className="text-emerald-400">Credential Sharing is ALLOWED</span>
                  </>
                )}
              </h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                {isLocked
                  ? 'All third-party employers and agencies attempting to verify your degree will be denied. You will receive an immediate SMS warning of any blocked attempt.'
                  : 'Authorized recruitment agencies, universities, and background verification desks can verify your degree and enrollment status.'}
              </p>
            </div>

            <button
              onClick={handleToggleConsent}
              className={`px-5 py-3 rounded-2xl font-bold text-xs shadow-lg transition flex items-center gap-2 cursor-pointer ${
                isLocked
                  ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                  : 'bg-rose-600 hover:bg-rose-500 text-white'
              }`}
            >
              {isLocked ? (
                <>
                  <Unlock className="w-4 h-4" />
                  <span>Unlock Credential Sharing</span>
                </>
              ) : (
                <>
                  <Lock className="w-4 h-4" />
                  <span>Lock Credential Sharing</span>
                </>
              )}
            </button>
          </div>

          <div className="text-xs text-slate-400 space-y-2 bg-slate-950/60 p-4 rounded-xl border border-slate-800">
            <h5 className="font-semibold text-slate-200">How Student Consent Works:</h5>
            <ul className="list-disc list-inside space-y-1 text-slate-400 text-[11px]">
              <li>When LOCKED: External verification requests return an explicit privacy lock notice.</li>
              <li>Every verification attempt (allowed or blocked) logs timestamp, verifier name, and IP address.</li>
              <li>You receive an instant alert on registered mobile: <code className="text-amber-300 font-mono">{activeStudent.contact_masked || '+91 98*** **412'}</code>.</li>
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};
