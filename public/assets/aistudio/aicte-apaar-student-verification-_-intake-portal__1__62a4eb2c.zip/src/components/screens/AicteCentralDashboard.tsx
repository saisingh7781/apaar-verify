/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Shield,
  Building,
  AlertTriangle,
  Users,
  CheckCircle2,
  TrendingUp,
  FileSpreadsheet,
  AlertOctagon,
  Eye,
  Send,
  Filter
} from 'lucide-react';
import { Institution, Student, IntakeAnalysis } from '../../types.ts';
import { calculateIntakeAnalysis } from '../../utils/validation.ts';
import { ScreenId } from '../Navbar.tsx';

interface AicteCentralDashboardProps {
  institutions: Institution[];
  students: Student[];
  onNavigate: (screen: ScreenId) => void;
  onSelectInstitution: (id: string) => void;
}

export const AicteCentralDashboard: React.FC<AicteCentralDashboardProps> = ({
  institutions,
  students,
  onNavigate,
  onSelectInstitution
}) => {
  const [selectedState, setSelectedState] = useState<string>('All');
  const [noticeSent, setNoticeSent] = useState<Record<string, boolean>>({});

  const analyses: IntakeAnalysis[] = institutions.map((inst) =>
    calculateIntakeAnalysis(inst, students)
  );

  const totalSanctioned = institutions.reduce((acc, i) => acc + i.approved_intake, 0);
  const totalEnrolled = students.length;
  const totalDuplicates = students.filter((s) => s.validation_status === 'Duplicate').length;
  const totalBreaches = analyses.filter((a) => a.is_exceeded).length;

  const handleSendNotice = (instId: string) => {
    setNoticeSent((prev) => ({ ...prev, [instId]: true }));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-md flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 font-mono">
              AICTE National HQ • Ministry of Education
            </span>
            <span className="text-xs text-slate-400">Regulator Central Command</span>
          </div>
          <h1 className="text-xl font-bold text-white mt-1">
            AICTE Central Student Registry & Intake Compliance Grid
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Macro-level institutional oversight, duplicate enrollment detection, and national seat cap audits
          </p>
        </div>

        {/* State Filter */}
        <div className="flex items-center gap-2 text-xs">
          <Filter className="w-4 h-4 text-slate-400" />
          <span className="text-slate-400 font-medium">State Region:</span>
          <select
            value={selectedState}
            onChange={(e) => setSelectedState(e.target.value)}
            className="px-3 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-white text-xs cursor-pointer focus:outline-hidden"
          >
            <option value="All">All States (National)</option>
            <option value="Tamil Nadu">Southern Region (Tamil Nadu)</option>
            <option value="Karnataka">South Western (Karnataka)</option>
            <option value="Maharashtra">Western Region (Maharashtra)</option>
          </select>
        </div>
      </div>

      {/* 4 National Macro Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Affiliated Colleges</span>
            <div className="w-8 h-8 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
              <Building className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-white">{institutions.length}</span>
            <span className="text-xs text-slate-400 font-medium">Institutes active</span>
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            <span>Approved Intake: {totalSanctioned} seats</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Total APAAR Ingested</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-white">{totalEnrolled}</span>
            <span className="text-xs text-slate-400 font-medium">Students</span>
          </div>
          <div className="mt-2 text-[11px] text-emerald-400 font-medium">
            <span>Overall Capacity: {Math.round((totalEnrolled / totalSanctioned) * 100)}%</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Capacity Breaches</span>
            <div className="w-8 h-8 rounded-lg bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400">
              <AlertOctagon className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className={`text-2xl font-extrabold ${totalBreaches > 0 ? 'text-rose-400' : 'text-white'}`}>
              {totalBreaches}
            </span>
            <span className="text-xs text-slate-400 font-medium">Colleges Exceeded</span>
          </div>
          <div className="mt-2 text-[11px] text-rose-400">
            <span>{totalBreaches > 0 ? 'Urgent notice issued' : 'All within cap'}</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">National Duplicates</span>
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className={`text-2xl font-extrabold ${totalDuplicates > 0 ? 'text-amber-400' : 'text-white'}`}>
              {totalDuplicates}
            </span>
            <span className="text-xs text-slate-400 font-medium">Concurrent Records</span>
          </div>
          <div className="mt-2 text-[11px] text-amber-300">
            <span>Flagged by cross-college APAAR matching</span>
          </div>
        </div>
      </div>

      {/* National Excess-Intake Alert Feed */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-md space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-bold text-sm text-white flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400" />
              National Excess-Intake & Duplicate Incident Feed
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Live automated alerts generated by backend validation workers
            </p>
          </div>
          <span className="text-xs font-medium px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
            AICTE Rules Enforced: APH 2026-27
          </span>
        </div>

        <div className="space-y-3">
          {/* Incident 1: PSG College Over-intake */}
          <div className="p-4 rounded-xl bg-rose-950/30 border border-rose-900/60 flex flex-wrap items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500 text-white uppercase">
                  Capacity Breach (105.6%)
                </span>
                <strong className="text-white text-xs">PSG College of Technology, Coimbatore</strong>
                <span className="text-[11px] text-slate-400 font-mono">(AICTE-TN-015)</span>
              </div>
              <p className="text-xs text-rose-200">
                Uploaded 95 students against sanctioned capacity of 90 (Excess of +5 admissions in Mechanical & Robotics branches).
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  onSelectInstitution('inst-3');
                  onNavigate('intake-monitoring');
                }}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium transition cursor-pointer flex items-center gap-1.5"
              >
                <Eye className="w-3.5 h-3.5" /> Inspect Intake
              </button>
              <button
                onClick={() => handleSendNotice('inst-3')}
                disabled={noticeSent['inst-3']}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer flex items-center gap-1.5 ${
                  noticeSent['inst-3']
                    ? 'bg-slate-800 text-slate-400 cursor-not-allowed'
                    : 'bg-rose-600 hover:bg-rose-500 text-white shadow'
                }`}
              >
                <Send className="w-3.5 h-3.5" />
                {noticeSent['inst-3'] ? 'Notice Dispatched' : 'Issue Inquiry Notice'}
              </button>
            </div>
          </div>

          {/* Incident 2: Dual Enrollment Conflict */}
          <div className="p-4 rounded-xl bg-amber-950/30 border border-amber-900/60 flex flex-wrap items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500 text-black uppercase">
                  Cross-University Duplicate
                </span>
                <strong className="text-white text-xs">Siddharth Natarajan</strong>
                <span className="text-[11px] text-amber-300 font-mono">APAAR: 5482-9103-7462</span>
              </div>
              <p className="text-xs text-amber-200">
                Simultaneously enrolled at <strong>Madras Institute of Technology</strong> (IT) AND <strong>College of Engineering Guindy</strong> (CSE).
              </p>
            </div>
            <button
              onClick={() => onNavigate('validation-results')}
              className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold transition cursor-pointer flex items-center gap-1.5 shadow"
            >
              Resolve in Validation Ledger
            </button>
          </div>
        </div>
      </div>

      {/* Institutional Macro Compliance Grid */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-md space-y-4">
        <div>
          <h3 className="font-bold text-sm text-white">National Affiliation Compliance Matrix</h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time synchronization across all approved engineering & technical institutions
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">AICTE Permanent ID</th>
                <th className="py-2.5 px-3">Institution Name</th>
                <th className="py-2.5 px-3">State</th>
                <th className="py-2.5 px-3">Approved Intake</th>
                <th className="py-2.5 px-3">APAAR Headcount</th>
                <th className="py-2.5 px-3">Utilization</th>
                <th className="py-2.5 px-3">Flagged Issues</th>
                <th className="py-2.5 px-3 text-right">Regulatory Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-sans">
              {analyses.map((analysis) => {
                const instStudents = students.filter((s) => s.institution_id === analysis.institution_id);
                const dupCount = instStudents.filter((s) => s.validation_status === 'Duplicate').length;
                const warnCount = instStudents.filter(
                  (s) => s.validation_status === 'Warning' || s.validation_status === 'Needs Review'
                ).length;
                const isOver = analysis.is_exceeded;

                return (
                  <tr key={analysis.institution_id} className="hover:bg-slate-800/40">
                    <td className="py-3 px-3 font-mono font-semibold text-slate-300">
                      {analysis.aicte_id}
                    </td>
                    <td className="py-3 px-3 font-semibold text-white">
                      {analysis.institution_name}
                    </td>
                    <td className="py-3 px-3 text-slate-400">Tamil Nadu</td>
                    <td className="py-3 px-3 font-mono text-slate-300">
                      {analysis.approved_intake} seats
                    </td>
                    <td className="py-3 px-3 font-mono font-bold text-white">
                      {analysis.enrolled_count}
                    </td>
                    <td className="py-3 px-3">
                      <span className={`font-bold ${isOver ? 'text-rose-400' : 'text-emerald-400'}`}>
                        {analysis.utilization_percentage}%
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-1.5">
                        {isOver && (
                          <span className="px-1.5 py-0.5 rounded text-[10px] bg-rose-500/20 text-rose-400 border border-rose-500/30 font-semibold">
                            +{analysis.excess_count} Excess
                          </span>
                        )}
                        {dupCount > 0 && (
                          <span className="px-1.5 py-0.5 rounded text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/30 font-semibold">
                            {dupCount} Dup
                          </span>
                        )}
                        {warnCount > 0 && (
                          <span className="px-1.5 py-0.5 rounded text-[10px] bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-semibold">
                            {warnCount} Warn
                          </span>
                        )}
                        {!isOver && dupCount === 0 && warnCount === 0 && (
                          <span className="text-emerald-400 flex items-center gap-1 text-[11px]">
                            <CheckCircle2 className="w-3.5 h-3.5" /> 100% Clean
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={() => {
                          onSelectInstitution(analysis.institution_id);
                          onNavigate('institution-dashboard');
                        }}
                        className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer text-xs font-medium"
                      >
                        Open Institute Portal
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
