/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  FileSpreadsheet,
  Download,
  Filter,
  Printer,
  CheckCircle2,
  Building,
  GraduationCap,
  Calendar,
  Layers,
  FileText
} from 'lucide-react';
import { Institution, Student, ValidationStatus, AdmissionCategory } from '../../types.ts';

interface ReportsPageProps {
  institutions: Institution[];
  students: Student[];
}

export const ReportsPage: React.FC<ReportsPageProps> = ({ institutions, students }) => {
  const [selectedInstId, setSelectedInstId] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedYear, setSelectedYear] = useState<string>('all');

  const filteredStudents = students.filter((s) => {
    if (selectedInstId !== 'all' && s.institution_id !== selectedInstId) return false;
    if (selectedStatus !== 'all' && s.validation_status !== selectedStatus) return false;
    if (selectedCategory !== 'all' && s.admission_category !== selectedCategory) return false;
    if (selectedYear !== 'all' && s.admission_year.toString() !== selectedYear) return false;
    return true;
  });

  const getInstitution = (id: string) => institutions.find((i) => i.id === id);

  const handleExportCSV = () => {
    const headers = 'APAAR ID,Roll Number,Student Name,Program,Institution,AICTE ID,Admission Year,Category,Validation Status,Validation Notes\n';
    const rows = filteredStudents.map((s) => {
      const inst = getInstitution(s.institution_id);
      return `"${s.apaar_id}","${s.student_id}","${s.full_name}","${s.program}","${inst?.name || ''}","${inst?.aicte_id || ''}","${s.admission_year}","${s.admission_category}","${s.validation_status}","${s.validation_notes || ''}"`;
    }).join('\n');

    const blob = new Blob([headers + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `AICTE_APAAR_Compliance_Report_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(filteredStudents, null, 2));
    const link = document.createElement('a');
    link.href = dataStr;
    link.download = `AICTE_APAAR_Audit_Export_${Date.now()}.json`;
    link.click();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-md flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 font-mono">
              AICTE Compliance Engine
            </span>
            <span className="text-xs text-slate-400">Statistical Analysis & Regulatory Exports</span>
          </div>
          <h1 className="text-xl font-bold text-white mt-1">
            Institutional Compliance & APAAR Audit Reports
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Generate and export signed compliance summaries for academic council approvals and NAAC/NBA reviews
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-xs shadow transition flex items-center gap-1.5 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={handleExportJSON}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-medium text-xs transition flex items-center gap-1.5 cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
            <span>Export JSON</span>
          </button>
        </div>
      </div>

      {/* Query Builder Filters */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-sm space-y-4">
        <div className="flex items-center gap-2 text-xs font-semibold text-white">
          <Filter className="w-4 h-4 text-indigo-400" />
          <span>Multi-Dimensional Audit Filter Builder</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
          {/* Institution */}
          <div>
            <label className="block text-slate-400 mb-1">Institution</label>
            <select
              value={selectedInstId}
              onChange={(e) => setSelectedInstId(e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white cursor-pointer focus:outline-hidden"
            >
              <option value="all">All Institutions</option>
              {institutions.map((i) => (
                <option key={i.id} value={i.id}>
                  {i.name.split(',')[0]} ({i.aicte_id})
                </option>
              ))}
            </select>
          </div>

          {/* Validation Status */}
          <div>
            <label className="block text-slate-400 mb-1">Validation Status</label>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white cursor-pointer focus:outline-hidden"
            >
              <option value="all">All Statuses</option>
              <option value="Valid">Valid (Green)</option>
              <option value="Duplicate">Duplicate (Red)</option>
              <option value="Warning">Warning (Amber)</option>
              <option value="Needs Review">Needs Review (Purple)</option>
            </select>
          </div>

          {/* Admission Category */}
          <div>
            <label className="block text-slate-400 mb-1">Quota Category</label>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white cursor-pointer focus:outline-hidden"
            >
              <option value="all">All Quotas</option>
              <option value="Regular">Regular</option>
              <option value="NRI">NRI Quota</option>
              <option value="Supernumerary">Supernumerary</option>
            </select>
          </div>

          {/* Academic Year */}
          <div>
            <label className="block text-slate-400 mb-1">Admission Year</label>
            <select
              value={selectedYear}
              onChange={(e) => setSelectedYear(e.target.value)}
              className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-white cursor-pointer focus:outline-hidden"
            >
              <option value="all">All Years</option>
              <option value="2026">2026-27 (Current)</option>
              <option value="2025">2025-26</option>
            </select>
          </div>
        </div>
      </div>

      {/* Certificate / Formal Preview Card */}
      <div className="bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">
                Official AICTE APAAR Enrollment & Intake Audit Summary
              </h3>
              <p className="text-xs text-slate-400">
                Generated dynamically under statutory provisions of AICTE Act, 1987
              </p>
            </div>
          </div>
          <span className="px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-mono">
            {filteredStudents.length} Records Matching Criteria
          </span>
        </div>

        {/* Breakdown Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs py-2">
          <div className="p-3 bg-slate-900/90 rounded-xl border border-slate-800">
            <span className="text-slate-400 block text-[11px]">Filtered Records</span>
            <span className="text-lg font-bold text-white">{filteredStudents.length}</span>
          </div>
          <div className="p-3 bg-slate-900/90 rounded-xl border border-slate-800">
            <span className="text-slate-400 block text-[11px]">Valid APAAR Records</span>
            <span className="text-lg font-bold text-emerald-400">
              {filteredStudents.filter((s) => s.validation_status === 'Valid').length}
            </span>
          </div>
          <div className="p-3 bg-slate-900/90 rounded-xl border border-slate-800">
            <span className="text-slate-400 block text-[11px]">Duplicate Incidents</span>
            <span className="text-lg font-bold text-rose-400">
              {filteredStudents.filter((s) => s.validation_status === 'Duplicate').length}
            </span>
          </div>
          <div className="p-3 bg-slate-900/90 rounded-xl border border-slate-800">
            <span className="text-slate-400 block text-[11px]">Format Warnings</span>
            <span className="text-lg font-bold text-amber-400">
              {filteredStudents.filter((s) => s.validation_status === 'Warning' || s.validation_status === 'Needs Review').length}
            </span>
          </div>
        </div>

        {/* Preview List */}
        <div className="overflow-x-auto border border-slate-800/80 rounded-xl">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">APAAR ID</th>
                <th className="py-2.5 px-3">Student Name</th>
                <th className="py-2.5 px-3">College Roll No</th>
                <th className="py-2.5 px-3">Program</th>
                <th className="py-2.5 px-3">Institution</th>
                <th className="py-2.5 px-3">Category</th>
                <th className="py-2.5 px-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-sans">
              {filteredStudents.slice(0, 15).map((s) => (
                <tr key={s.id} className="hover:bg-slate-800/40">
                  <td className="py-2.5 px-3 font-mono font-semibold text-white">
                    {s.apaar_id || 'Missing'}
                  </td>
                  <td className="py-2.5 px-3 font-medium text-slate-200">{s.full_name}</td>
                  <td className="py-2.5 px-3 font-mono text-slate-400">{s.student_id}</td>
                  <td className="py-2.5 px-3 text-slate-300">{s.program}</td>
                  <td className="py-2.5 px-3 text-slate-400 text-[11px]">
                    {getInstitution(s.institution_id)?.name.split(',')[0]}
                  </td>
                  <td className="py-2.5 px-3 text-slate-400">{s.admission_category}</td>
                  <td className="py-2.5 px-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                        s.validation_status === 'Valid'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : s.validation_status === 'Duplicate'
                          ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                          : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                      }`}
                    >
                      {s.validation_status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredStudents.length > 15 && (
          <p className="text-xs text-slate-400 text-center pt-2">
            Showing first 15 of {filteredStudents.length} records. Export full report via CSV button above.
          </p>
        )}
      </div>
    </div>
  );
};
