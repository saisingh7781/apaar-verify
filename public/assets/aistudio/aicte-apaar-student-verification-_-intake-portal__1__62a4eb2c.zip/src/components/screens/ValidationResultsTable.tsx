/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  FileCheck2,
  Search,
  Filter,
  AlertTriangle,
  CheckCircle2,
  Edit2,
  Trash2,
  Download,
  AlertCircle,
  HelpCircle,
  Building
} from 'lucide-react';
import { Student, ValidationStatus, Institution } from '../../types.ts';
import { EditStudentModal } from '../EditStudentModal.tsx';
import { isValidApaarId } from '../../utils/validation.ts';

interface ValidationResultsTableProps {
  students: Student[];
  institutions: Institution[];
  onUpdateStudent: (studentId: string, updates: Partial<Student>) => void;
  onDeleteStudent: (studentId: string) => void;
  selectedInstitutionId?: string;
  onSelectInstitution?: (id: string) => void;
}

export const ValidationResultsTable: React.FC<ValidationResultsTableProps> = ({
  students,
  institutions,
  onUpdateStudent,
  onDeleteStudent,
  selectedInstitutionId,
  onSelectInstitution
}) => {
  const [statusFilter, setStatusFilter] = useState<'All' | ValidationStatus>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);

  // Filter students
  const filteredStudents = students.filter((s) => {
    if (selectedInstitutionId && selectedInstitutionId !== 'all' && s.institution_id !== selectedInstitutionId) {
      return false;
    }
    if (statusFilter !== 'All' && s.validation_status !== statusFilter) {
      return false;
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        s.full_name.toLowerCase().includes(q) ||
        s.apaar_id.toLowerCase().includes(q) ||
        s.student_id.toLowerCase().includes(q) ||
        s.program.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const countByStatus = {
    All: students.length,
    Valid: students.filter((s) => s.validation_status === 'Valid').length,
    Duplicate: students.filter((s) => s.validation_status === 'Duplicate').length,
    Warning: students.filter((s) => s.validation_status === 'Warning').length,
    'Needs Review': students.filter((s) => s.validation_status === 'Needs Review').length
  };

  const getInstitutionName = (id: string) => {
    return institutions.find((i) => i.id === id)?.name || 'Unknown College';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-md flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 font-mono">
              National Deduplication Engine
            </span>
            <span className="text-xs text-slate-400">PostgreSQL Indexed Student Registry</span>
          </div>
          <h1 className="text-xl font-bold text-white mt-1">
            Validation Results & Data Integrity Ledger
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Identify duplicate registrations across universities, intake cap overflows, and format anomalies
          </p>
        </div>

        {/* College Filter */}
        {onSelectInstitution && (
          <div className="flex items-center gap-2 text-xs">
            <Building className="w-4 h-4 text-slate-400" />
            <select
              value={selectedInstitutionId || 'all'}
              onChange={(e) => onSelectInstitution(e.target.value)}
              className="px-3 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-white text-xs cursor-pointer focus:outline-hidden"
            >
              <option value="all">All Institutions ({institutions.length})</option>
              {institutions.map((inst) => (
                <option key={inst.id} value={inst.id}>
                  {inst.name.split(',')[0]} ({inst.aicte_id})
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      {/* Status Filter Tabs & Search Controls */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-sm space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          {/* Status Tabs */}
          <div className="flex flex-wrap gap-2 text-xs">
            {(['All', 'Valid', 'Duplicate', 'Warning', 'Needs Review'] as const).map((status) => {
              const count = countByStatus[status];
              const isActive = statusFilter === status;

              const badgeColors = {
                All: 'bg-slate-800 text-slate-300',
                Valid: 'bg-emerald-500/20 text-emerald-300',
                Duplicate: 'bg-rose-500/20 text-rose-300',
                Warning: 'bg-amber-500/20 text-amber-300',
                'Needs Review': 'bg-indigo-500/20 text-indigo-300'
              };

              return (
                <button
                  key={status}
                  onClick={() => setStatusFilter(status)}
                  className={`px-3 py-1.5 rounded-xl font-medium transition cursor-pointer flex items-center gap-2 ${
                    isActive
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'bg-slate-800/80 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-700/60'
                  }`}
                >
                  <span>{status}</span>
                  <span
                    className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                      isActive ? 'bg-white/20 text-white' : badgeColors[status]
                    }`}
                  >
                    {count}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Search Box */}
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search Name, APAAR ID, Roll..."
              className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs placeholder:text-slate-500 focus:outline-hidden focus:border-indigo-500"
            />
          </div>
        </div>
      </div>

      {/* Students Results Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-lg">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Validation Status</th>
                <th className="py-3 px-4">12-Digit APAAR ID</th>
                <th className="py-3 px-4">Student Name</th>
                <th className="py-3 px-4">College Roll No</th>
                <th className="py-3 px-4">Program / Branch</th>
                <th className="py-3 px-4">Institution</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Engine Diagnostics</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredStudents.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-slate-500 text-xs">
                    No student records match the active filters.
                  </td>
                </tr>
              ) : (
                filteredStudents.map((student) => {
                  const isDup = student.validation_status === 'Duplicate';
                  const isWarn = student.validation_status === 'Warning';
                  const isReview = student.validation_status === 'Needs Review';
                  const isOk = student.validation_status === 'Valid';
                  const formattedApaar = isValidApaarId(student.apaar_id).formatted || student.apaar_id;

                  return (
                    <tr
                      key={student.id}
                      className={`transition ${
                        isDup
                          ? 'bg-rose-950/20 hover:bg-rose-950/30'
                          : isWarn
                          ? 'bg-amber-950/20 hover:bg-amber-950/30'
                          : isReview
                          ? 'bg-indigo-950/20 hover:bg-indigo-950/30'
                          : 'hover:bg-slate-800/40'
                      }`}
                    >
                      {/* Status Tag */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span
                          className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold ${
                            isOk
                              ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                              : isDup
                              ? 'bg-rose-500/15 text-rose-400 border border-rose-500/40 animate-pulse'
                              : isWarn
                              ? 'bg-amber-500/15 text-amber-400 border border-amber-500/40'
                              : 'bg-indigo-500/15 text-indigo-400 border border-indigo-500/40'
                          }`}
                        >
                          {isOk && <CheckCircle2 className="w-3 h-3" />}
                          {isDup && <AlertTriangle className="w-3 h-3 text-rose-400" />}
                          {isWarn && <AlertCircle className="w-3 h-3 text-amber-400" />}
                          {isReview && <HelpCircle className="w-3 h-3 text-indigo-400" />}
                          {student.validation_status}
                        </span>
                      </td>

                      {/* APAAR ID */}
                      <td className="py-3 px-4 font-mono font-semibold text-white whitespace-nowrap">
                        {student.apaar_id ? (
                          <span>{formattedApaar}</span>
                        ) : (
                          <span className="text-rose-400 font-sans italic text-[11px]">Unregistered</span>
                        )}
                      </td>

                      {/* Student Name */}
                      <td className="py-3 px-4 font-semibold text-slate-200 whitespace-nowrap">
                        {student.full_name}
                      </td>

                      {/* Roll Number */}
                      <td className="py-3 px-4 font-mono text-slate-400 whitespace-nowrap">
                        {student.student_id}
                      </td>

                      {/* Program */}
                      <td className="py-3 px-4 text-slate-300 max-w-[180px] truncate" title={student.program}>
                        {student.program}
                      </td>

                      {/* Institution */}
                      <td className="py-3 px-4 text-slate-400 text-[11px] max-w-[160px] truncate" title={getInstitutionName(student.institution_id)}>
                        {getInstitutionName(student.institution_id).split(',')[0]}
                      </td>

                      {/* Category */}
                      <td className="py-3 px-4 text-slate-400 whitespace-nowrap">
                        <span className="px-2 py-0.5 rounded bg-slate-800 text-[10px] font-medium text-slate-300 border border-slate-700/60">
                          {student.admission_category}
                        </span>
                      </td>

                      {/* Diagnostic Notes */}
                      <td className="py-3 px-4 text-[11px] max-w-[220px]">
                        <span
                          className={`line-clamp-2 ${
                            isDup ? 'text-rose-300 font-medium' : isWarn ? 'text-amber-300' : 'text-slate-400'
                          }`}
                          title={student.validation_notes}
                        >
                          {student.validation_notes || 'Clean record'}
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => setEditingStudent(student)}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-indigo-600 text-slate-300 hover:text-white transition cursor-pointer"
                            title="Edit & correct student APAAR record"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => {
                              if (confirm(`Remove student ${student.full_name} from registry?`)) {
                                onDeleteStudent(student.id);
                              }
                            }}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-600 text-slate-300 hover:text-white transition cursor-pointer"
                            title="Delete student record"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Row Edit Modal */}
      <EditStudentModal
        student={editingStudent}
        isOpen={!!editingStudent}
        onClose={() => setEditingStudent(null)}
        onSave={onUpdateStudent}
      />
    </div>
  );
};
