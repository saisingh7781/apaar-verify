/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Users,
  AlertTriangle,
  FileCheck,
  Building,
  UploadCloud,
  CheckCircle2,
  Gauge,
  ArrowRight,
  TrendingUp,
  ShieldAlert,
  GraduationCap
} from 'lucide-react';
import { Institution, Student, IntakeAnalysis } from '../../types.ts';
import { ScreenId } from '../Navbar.tsx';

interface InstitutionDashboardProps {
  institution: Institution;
  students: Student[];
  intakeAnalysis: IntakeAnalysis;
  onNavigate: (screen: ScreenId) => void;
  institutions: Institution[];
  onSelectInstitution: (id: string) => void;
}

export const InstitutionDashboard: React.FC<InstitutionDashboardProps> = ({
  institution,
  students,
  intakeAnalysis,
  onNavigate,
  institutions,
  onSelectInstitution
}) => {
  const institutionStudents = students.filter(s => s.institution_id === institution.id);
  const validCount = institutionStudents.filter(s => s.validation_status === 'Valid').length;
  const duplicateCount = institutionStudents.filter(s => s.validation_status === 'Duplicate').length;
  const warningCount = institutionStudents.filter(s => s.validation_status === 'Warning' || s.validation_status === 'Needs Review').length;

  const isBreached = intakeAnalysis.is_exceeded;
  const utilization = intakeAnalysis.utilization_percentage;

  return (
    <div className="space-y-6">
      {/* Institution Switcher & Header */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-md flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 font-mono">
              {institution.aicte_id}
            </span>
            <span className="text-xs text-slate-400">{institution.state} State Jurisdiction</span>
          </div>
          <h1 className="text-xl font-bold text-white mt-1 tracking-tight">
            {institution.name}
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Institutional APAAR Registry & AICTE Sanctioned Quota Oversight
          </p>
        </div>

        {/* College Switcher */}
        <div className="flex items-center gap-2 text-xs">
          <label className="text-slate-400 font-medium hidden sm:inline">Active College:</label>
          <select
            value={institution.id}
            onChange={(e) => onSelectInstitution(e.target.value)}
            className="px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-white text-xs focus:outline-hidden focus:border-indigo-500 cursor-pointer"
          >
            {institutions.map(inst => (
              <option key={inst.id} value={inst.id}>
                {inst.name.split(',')[0]} ({inst.aicte_id})
              </option>
            ))}
          </select>
          <button
            onClick={() => onNavigate('student-upload')}
            className="px-3.5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-medium flex items-center gap-1.5 transition cursor-pointer shadow-sm"
          >
            <UploadCloud className="w-3.5 h-3.5" />
            <span>Upload New Batch</span>
          </button>
        </div>
      </div>

      {/* Critical Alert Banners */}
      {isBreached && (
        <div className="p-4 rounded-xl bg-rose-500/10 border-2 border-rose-500/50 flex flex-wrap sm:flex-nowrap items-start justify-between gap-4 text-rose-200">
          <div className="flex items-start gap-3">
            <ShieldAlert className="w-5 h-5 text-rose-400 shrink-0 mt-0.5 animate-pulse" />
            <div>
              <h4 className="font-bold text-sm text-white flex items-center gap-2">
                CRITICAL WARNING: Approved Intake Capacity Exceeded!
                <span className="px-2 py-0.5 rounded text-[10px] bg-rose-500 text-white font-bold">
                  {intakeAnalysis.excess_count} Excess Students
                </span>
              </h4>
              <p className="text-xs text-rose-200/90 mt-1">
                Your institution has enrolled {intakeAnalysis.enrolled_count} students against a sanctioned batch capacity of {institution.approved_intake} ({utilization}%).
                Unsanctioned excess admissions are in non-compliance with AICTE Approval Process Handbook (APH) regulations.
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigate('intake-monitoring')}
            className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold rounded-lg shrink-0 transition cursor-pointer"
          >
            Inspect Intake Breakdown
          </button>
        </div>
      )}

      {duplicateCount > 0 && (
        <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/40 flex flex-wrap sm:flex-nowrap items-start justify-between gap-4 text-amber-200">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="font-bold text-sm text-white">
                Duplicate APAAR ID Alert ({duplicateCount} conflict{duplicateCount > 1 ? 's' : ''})
              </h4>
              <p className="text-xs text-amber-200/90 mt-1">
                National deduplication engine identified students registered concurrently in other AICTE colleges or programs.
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigate('validation-results')}
            className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold rounded-lg shrink-0 transition cursor-pointer"
          >
            Resolve Duplicates
          </button>
        </div>
      )}

      {/* 4 Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Total Enrolled */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Total Enrolled</span>
            <div className="w-8 h-8 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-white">{institutionStudents.length}</span>
            <span className="text-xs text-slate-400 font-medium">Students</span>
          </div>
          <div className="mt-2 text-[11px] text-slate-400 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
            <span>{validCount} verified with National APAAR</span>
          </div>
        </div>

        {/* Card 2: Sanctioned Capacity */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Approved Intake</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <Building className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-white">{institution.approved_intake}</span>
            <span className="text-xs text-slate-400 font-medium">Sanctioned Seats</span>
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            <span>Per AICTE Approval Order 2026-27</span>
          </div>
        </div>

        {/* Card 3: Utilization Gauge */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Capacity Utilization</span>
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
              isBreached ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' : 'bg-sky-500/10 text-sky-400 border border-sky-500/20'
            }`}>
              <Gauge className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className={`text-2xl font-extrabold ${isBreached ? 'text-rose-400' : 'text-white'}`}>
              {utilization}%
            </span>
            <span className="text-xs text-slate-400 font-medium">of Quota</span>
          </div>
          {/* Progress Mini Bar */}
          <div className="w-full bg-slate-800 h-1.5 rounded-full mt-2.5 overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                isBreached ? 'bg-rose-500' : utilization > 85 ? 'bg-amber-400' : 'bg-emerald-500'
              }`}
              style={{ width: `${Math.min(utilization, 100)}%` }}
            />
          </div>
        </div>

        {/* Card 4: Anomalies & Errors */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Pending Flags</span>
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
              duplicateCount + warningCount > 0 ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' : 'bg-slate-800 text-slate-400'
            }`}>
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className={`text-2xl font-extrabold ${duplicateCount + warningCount > 0 ? 'text-amber-400' : 'text-slate-200'}`}>
              {duplicateCount + warningCount}
            </span>
            <span className="text-xs text-slate-400 font-medium">Issues</span>
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            <span>{duplicateCount} duplicates • {warningCount} format errors</span>
          </div>
        </div>
      </div>

      {/* Program Breakdown & Action Shortcuts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Program Enrollment Distribution */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-bold text-sm text-white">Program-Level Enrollment Distribution</h3>
              <p className="text-xs text-slate-400">Aggregated real-time headcount across active AICTE disciplines</p>
            </div>
            <button
              onClick={() => onNavigate('intake-monitoring')}
              className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 font-medium cursor-pointer"
            >
              Detailed Breakdown <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {Object.entries(intakeAnalysis.program_breakdown).length === 0 ? (
              <p className="text-xs text-slate-400 py-4 text-center">No students registered yet.</p>
            ) : (
              Object.entries(intakeAnalysis.program_breakdown).map(([prog, count]) => {
                const progShare = Math.round((count / institutionStudents.length) * 100) || 0;
                return (
                  <div key={prog} className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="font-medium text-slate-200">{prog}</span>
                      <span className="text-slate-400 font-mono">
                        {count} students <span className="text-slate-500">({progShare}%)</span>
                      </span>
                    </div>
                    <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-indigo-500 h-full rounded-full transition-all duration-300"
                        style={{ width: `${progShare}%` }}
                      />
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right 1 Col: Quick Actions & Compliance Health */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-sm space-y-5 flex flex-col justify-between">
          <div>
            <h3 className="font-bold text-sm text-white mb-1">Administrative Shortcuts</h3>
            <p className="text-xs text-slate-400 mb-4">Core workflows for institutional nodal officers</p>

            <div className="space-y-2">
              <button
                onClick={() => onNavigate('student-upload')}
                className="w-full p-3 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700 text-left transition flex items-center justify-between group cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center">
                    <UploadCloud className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-white group-hover:text-indigo-300 transition">
                      Batch CSV/Excel Upload
                    </div>
                    <div className="text-[11px] text-slate-400">Upload entire fresh batch of admissions</div>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-500 group-hover:translate-x-1 transition" />
              </button>

              <button
                onClick={() => onNavigate('validation-results')}
                className="w-full p-3 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700 text-left transition flex items-center justify-between group cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
                    <FileCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-white group-hover:text-amber-300 transition">
                      Validation & Duplicate Table
                    </div>
                    <div className="text-[11px] text-slate-400">Review flagged APAAR records</div>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-500 group-hover:translate-x-1 transition" />
              </button>

              <button
                onClick={() => onNavigate('reports')}
                className="w-full p-3 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700 text-left transition flex items-center justify-between group cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                    <TrendingUp className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-white group-hover:text-emerald-300 transition">
                      Export Compliance Reports
                    </div>
                    <div className="text-[11px] text-slate-400">Download AICTE intake certificate</div>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-500 group-hover:translate-x-1 transition" />
              </button>
            </div>
          </div>

          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-[11px] text-slate-400">
            <div className="flex items-center justify-between font-semibold text-slate-300 mb-1">
              <span>National Academic Depository Link</span>
              <span className="text-emerald-400 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" /> Active
              </span>
            </div>
            <span>All records sync automatically with student DigiLocker credit banks.</span>
          </div>
        </div>
      </div>
    </div>
  );
};
