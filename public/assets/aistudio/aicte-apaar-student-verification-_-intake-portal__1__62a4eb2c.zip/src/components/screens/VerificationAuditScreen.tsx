/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  QrCode,
  Search,
  ShieldCheck,
  Smartphone,
  CheckCircle2,
  AlertTriangle,
  History,
  Building,
  GraduationCap,
  Sparkles,
  ExternalLink,
  Camera
} from 'lucide-react';
import { Student, AccessAuditLog } from '../../types.ts';
import { apiService, VerificationResult } from '../../services/apiService.ts';
import { isValidApaarId } from '../../utils/validation.ts';

interface VerificationAuditScreenProps {
  students: Student[];
  auditLogs: AccessAuditLog[];
  onTriggerAlert: (result: VerificationResult) => void;
}

export const VerificationAuditScreen: React.FC<VerificationAuditScreenProps> = ({
  students,
  auditLogs,
  onTriggerAlert
}) => {
  const [apaarInput, setApaarInput] = useState('1234-5678-9012');
  const [verifierName, setVerifierName] = useState('Tata Consultancy Services (TCS) Campus Verification Desk');
  const [activeVerification, setActiveVerification] = useState<VerificationResult | null>(null);
  const [isScanning, setIsScanning] = useState(false);

  const handleVerify = (targetApaar?: string, customVerifier?: string) => {
    const idToVerify = targetApaar || apaarInput;
    const verifier = customVerifier || verifierName;

    const result = apiService.verifyCredential(
      idToVerify,
      verifier,
      '14.143.190.' + Math.floor(10 + Math.random() * 80)
    );

    setActiveVerification(result);
    onTriggerAlert(result);
  };

  const handleSimulateQrScan = (student: Student) => {
    setIsScanning(true);
    setTimeout(() => {
      setIsScanning(false);
      setApaarInput(student.apaar_id);
      handleVerify(student.apaar_id, `National Recruitment Audit (${student.full_name.split(' ')[0]})`);
    }, 400);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-md flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-amber-500/10 text-amber-300 border border-amber-500/20 font-mono">
              POST /api/v1/verify/credential
            </span>
            <span className="text-xs text-slate-400">Student-First Privacy & Real-Time Alert Engine</span>
          </div>
          <h1 className="text-xl font-bold text-white mt-1">
            APAAR Credential Verification & Real-Time Access Ledger
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Every verification lookup instantly triggers a registered SMS alert to the student for absolute transparency
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => handleVerify()}
            className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-semibold text-xs shadow-md transition flex items-center gap-2 cursor-pointer"
          >
            <Smartphone className="w-4 h-4 animate-bounce" />
            <span>Simulate Live Verification & SMS</span>
          </button>
        </div>
      </div>

      {/* Grid: Left Column Verification Console, Right Column QR & Credential Card */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Lookup & QR Console */}
        <div className="lg:col-span-7 space-y-6">
          {/* Lookup Input Card */}
          <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-sm space-y-4">
            <h3 className="font-bold text-sm text-white flex items-center gap-2">
              <Search className="w-4 h-4 text-indigo-400" />
              Direct National APAAR / ABC ID Query
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  National APAAR ID (12-Digit)
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={apaarInput}
                    onChange={(e) => setApaarInput(e.target.value)}
                    placeholder="e.g. 1234-5678-9012"
                    className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono text-sm focus:outline-hidden focus:border-indigo-500"
                  />
                  <span className="absolute right-3 top-3 text-[11px] text-slate-500">
                    {isValidApaarId(apaarInput).valid ? '✓ Valid Format' : 'Must be 12 digits'}
                  </span>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Querying Agency / Verifier Entity
                </label>
                <input
                  type="text"
                  value={verifierName}
                  onChange={(e) => setVerifierName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <button
                onClick={() => handleVerify()}
                className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs transition flex items-center justify-center gap-2 shadow-md cursor-pointer"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>Verify Credential & Dispatch Student Alert</span>
              </button>
            </div>

            {/* Quick Demo Student Clickers */}
            <div className="pt-3 border-t border-slate-800">
              <span className="text-[11px] font-semibold text-slate-400 block mb-2">
                Quick Presentation Samples:
              </span>
              <div className="flex flex-wrap gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => {
                    setApaarInput('123456789012');
                    setVerifierName('Tata Consultancy Services (TCS) Campus Verification Desk');
                    handleVerify('123456789012', 'Tata Consultancy Services (TCS) Campus Verification Desk');
                  }}
                  className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition cursor-pointer flex items-center gap-1.5"
                >
                  <Sparkles className="w-3 h-3 text-amber-400" />
                  <span>Aarav Ramanathan (MIT)</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setApaarInput('548291037462');
                    setVerifierName('Anna University Registrar Office');
                    handleVerify('548291037462', 'Anna University Registrar Office');
                  }}
                  className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-rose-300 border border-rose-900/60 transition cursor-pointer flex items-center gap-1.5"
                >
                  <AlertTriangle className="w-3 h-3 text-rose-400" />
                  <span>Siddharth Natarajan (Duplicate Alert)</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setApaarInput('234567890123');
                    setVerifierName('Amazon Web Services (AWS) India Talent Acquisition');
                    handleVerify('234567890123', 'Amazon Web Services (AWS) India Talent Acquisition');
                  }}
                  className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition cursor-pointer flex items-center gap-1.5"
                >
                  <span>Kavya Sundaram (MIT)</span>
                </button>
              </div>
            </div>
          </div>

          {/* QR Code Scanner Simulation */}
          <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm text-white flex items-center gap-2">
                  <Camera className="w-4 h-4 text-emerald-400" />
                  Camera / QR Code Optical Scanner Interface
                </h3>
                <p className="text-xs text-slate-400">
                  Simulate scanning student DigiLocker APAAR QR card
                </p>
              </div>
              <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                Webcam Scanner Ready
              </span>
            </div>

            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 flex flex-col items-center justify-center text-center space-y-3">
              <div className="w-32 h-32 rounded-xl border-2 border-indigo-500/60 p-2 bg-slate-900 flex flex-col items-center justify-center relative group">
                <QrCode className="w-20 h-20 text-slate-400 group-hover:text-indigo-400 transition" />
                <div className="absolute inset-0 bg-indigo-500/10 opacity-0 group-hover:opacity-100 rounded-xl transition flex items-center justify-center">
                  <span className="text-[10px] text-white font-bold bg-indigo-600 px-2 py-1 rounded">
                    Simulate Scan
                  </span>
                </div>
              </div>
              <p className="text-xs text-slate-400">
                Click any sample candidate below to simulate instant optical QR scan:
              </p>

              <div className="flex flex-wrap justify-center gap-2">
                {students.slice(0, 4).map((s) => (
                  <button
                    key={s.id}
                    onClick={() => handleSimulateQrScan(s)}
                    className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-indigo-600 text-slate-300 hover:text-white text-xs transition cursor-pointer font-medium"
                  >
                    Scan {s.full_name.split(' ')[0]}'s QR
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Verified Credential Card & Alert Notice */}
        <div className="lg:col-span-5 space-y-6">
          {activeVerification && activeVerification.student ? (
            <div className="bg-gradient-to-b from-slate-900 via-slate-900 to-indigo-950/40 border-2 border-indigo-500/60 rounded-3xl p-6 shadow-2xl relative overflow-hidden space-y-5 animate-in fade-in">
              {/* Official Seal Watermark */}
              <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                <div className="flex items-center gap-2">
                  <div className="w-9 h-9 rounded-xl bg-indigo-600 flex items-center justify-center text-white">
                    <GraduationCap className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-sm text-white tracking-wide">
                      NATIONAL APAAR CREDENTIAL
                    </h4>
                    <span className="text-[10px] text-indigo-300 uppercase tracking-wider font-semibold">
                      AICTE • ABC • DigiLocker Verified
                    </span>
                  </div>
                </div>

                <span
                  className={`px-2.5 py-1 rounded-full text-xs font-bold ${
                    activeVerification.student.validation_status === 'Valid'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : activeVerification.student.validation_status === 'Duplicate'
                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                      : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  }`}
                >
                  {activeVerification.student.validation_status === 'Valid' ? '✓ VERIFIED ACTIVE' : activeVerification.student.validation_status}
                </span>
              </div>

              {/* Student Identity Details */}
              <div className="space-y-3 text-xs">
                <div>
                  <span className="text-[11px] text-slate-400 block">Student Full Name</span>
                  <span className="text-base font-bold text-white">
                    {activeVerification.student.full_name}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <span className="text-[11px] text-slate-400 block">12-Digit APAAR ID</span>
                    <span className="font-mono text-amber-300 font-bold text-sm">
                      {isValidApaarId(activeVerification.student.apaar_id).formatted || activeVerification.student.apaar_id}
                    </span>
                  </div>
                  <div>
                    <span className="text-[11px] text-slate-400 block">College Roll Number</span>
                    <span className="font-mono text-slate-200 font-semibold">
                      {activeVerification.student.student_id}
                    </span>
                  </div>
                </div>

                <div>
                  <span className="text-[11px] text-slate-400 block">Degree Program</span>
                  <span className="text-slate-200 font-medium">
                    {activeVerification.student.program}
                  </span>
                </div>

                <div>
                  <span className="text-[11px] text-slate-400 block">AICTE Affiliated College</span>
                  <span className="text-slate-200 font-medium">
                    {activeVerification.institution?.name || 'Approved Institution'}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <span className="text-[11px] text-slate-400 block">Admission Year</span>
                    <span className="text-slate-300">{activeVerification.student.admission_year}</span>
                  </div>
                  <div>
                    <span className="text-[11px] text-slate-400 block">Quota Category</span>
                    <span className="text-slate-300">{activeVerification.student.admission_category}</span>
                  </div>
                </div>
              </div>

              {/* Alert Confirmation Box */}
              <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-800 text-[11px] space-y-1">
                <div className="flex items-center justify-between text-emerald-400 font-semibold">
                  <span className="flex items-center gap-1.5">
                    <Smartphone className="w-3.5 h-3.5" /> Real-Time Alert Dispatched
                  </span>
                  <span>SMS & Email</span>
                </div>
                <p className="text-slate-400 text-[10px]">
                  Dispatched to {activeVerification.student.contact_masked || '+91 98*** **412'} notifying them of lookup by{' '}
                  <strong className="text-slate-300">{activeVerification.auditLog.verifier_entity}</strong>.
                </p>
              </div>
            </div>
          ) : (
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 text-center space-y-4 shadow-md">
              <div className="w-16 h-16 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 mx-auto flex items-center justify-center text-indigo-400">
                <ShieldCheck className="w-8 h-8" />
              </div>
              <h3 className="font-bold text-base text-white">Student Credential Verification</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Enter any 12-digit APAAR ID or scan a student QR code to inspect credentials and view the instant access alert dispatch.
              </p>
              <button
                onClick={() => handleVerify('123456789012', 'Tata Consultancy Services (TCS) Campus Verification Desk')}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold cursor-pointer transition shadow"
              >
                Inspect Sample Verified Record
              </button>
            </div>
          )}

          {/* Privacy & Alert Explanation Box */}
          <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl shadow-sm text-xs space-y-2">
            <h4 className="font-bold text-white flex items-center gap-1.5">
              <Smartphone className="w-4 h-4 text-amber-400" />
              Real-Time Student Notification Architecture
            </h4>
            <p className="text-slate-400 text-[11px] leading-relaxed">
              In accordance with AICTE Student Data Privacy Guidelines, students receive an instant SMS whenever their academic records are accessed.
              This guarantees transparent audit trails and empowers students against unauthorized credential scraping.
            </p>
          </div>
        </div>
      </div>

      {/* Live Access Audit Log Ledger */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-md space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-bold text-sm text-white flex items-center gap-2">
              <History className="w-4 h-4 text-indigo-400" />
              PostgreSQL <code className="font-mono text-indigo-300">access_audit_logs</code> Ledger
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Immutable security ledger logging every verifier query, client IP, timestamp, and SMS dispatch status
            </p>
          </div>
          <span className="text-[11px] text-slate-400">
            Total Access Events: <strong className="text-white">{auditLogs.length}</strong>
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Log ID</th>
                <th className="py-2.5 px-3">APAAR ID</th>
                <th className="py-2.5 px-3">Student Name</th>
                <th className="py-2.5 px-3">Verifier Entity</th>
                <th className="py-2.5 px-3">Access Timestamp</th>
                <th className="py-2.5 px-3">IP Address</th>
                <th className="py-2.5 px-3 text-right">Student Alert</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-sans">
              {auditLogs.map((log) => (
                <tr key={log.log_id} className="hover:bg-slate-800/40">
                  <td className="py-2.5 px-3 font-mono text-slate-500 text-[11px]">
                    {log.log_id.slice(0, 12)}
                  </td>
                  <td className="py-2.5 px-3 font-mono font-bold text-amber-300">
                    {log.apaar_id}
                  </td>
                  <td className="py-2.5 px-3 font-medium text-white">
                    {log.student_name || 'Candidate'}
                  </td>
                  <td className="py-2.5 px-3 text-slate-300 font-medium">
                    {log.verifier_entity}
                  </td>
                  <td className="py-2.5 px-3 text-slate-400 font-mono text-[11px]">
                    {log.access_timestamp}
                  </td>
                  <td className="py-2.5 px-3 font-mono text-slate-400">
                    {log.ip_address}
                  </td>
                  <td className="py-2.5 px-3 text-right">
                    {log.alert_dispatched ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                        <CheckCircle2 className="w-3 h-3" /> SMS Dispatched
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-800 text-slate-400">
                        Pending
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
