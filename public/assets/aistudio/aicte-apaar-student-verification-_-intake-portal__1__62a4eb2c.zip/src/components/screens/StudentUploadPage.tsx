/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  UploadCloud,
  FileSpreadsheet,
  Download,
  AlertTriangle,
  CheckCircle2,
  FileCheck2,
  Sparkles,
  ArrowRight,
  RefreshCw,
  Info
} from 'lucide-react';
import { Institution, Student } from '../../types.ts';
import { SAMPLE_BATCH_CSV } from '../../data/seedData.ts';
import { parseCSVToStudents, evaluateStudentRecord, isValidApaarId } from '../../utils/validation.ts';
import { apiService } from '../../services/apiService.ts';
import { ScreenId } from '../Navbar.tsx';

interface StudentUploadPageProps {
  institution: Institution;
  institutions: Institution[];
  onSelectInstitution: (id: string) => void;
  onUploadSuccess: () => void;
  onNavigate: (screen: ScreenId) => void;
}

export const StudentUploadPage: React.FC<StudentUploadPageProps> = ({
  institution,
  institutions,
  onSelectInstitution,
  onUploadSuccess,
  onNavigate
}) => {
  const [csvContent, setCsvContent] = useState<string>('');
  const [fileName, setFileName] = useState<string>('');
  const [isDragging, setIsDragging] = useState(false);
  const [previewRows, setPreviewRows] = useState<any[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [uploadFeedback, setUploadFeedback] = useState<{
    success: boolean;
    total: number;
    valid: number;
    warnings: number;
    duplicates: number;
  } | null>(null);

  const processCsvText = (text: string, name = 'uploaded_batch.csv') => {
    setCsvContent(text);
    setFileName(name);
    setUploadFeedback(null);

    const parsed = parseCSVToStudents(text);
    const existing = apiService.getStudents();
    const evaluated = parsed.records.map((rec) => {
      const evalRes = evaluateStudentRecord(rec, existing, parsed.records as any);
      return {
        ...rec,
        computedStatus: evalRes.status,
        notes: evalRes.notes
      };
    });
    setPreviewRows(evaluated);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        processCsvText(text, file.name);
      };
      reader.readAsText(file);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        processCsvText(text, file.name);
      };
      reader.readAsText(file);
    }
  };

  const handleLoadSampleBatch = () => {
    processCsvText(SAMPLE_BATCH_CSV, 'aicte_mit_sample_admissions_2026.csv');
  };

  const handleDownloadTemplate = () => {
    const templateContent = `apaar_id,student_id,full_name,program,admission_year,admission_category
123456789012,ROLL-001,Aarav Ramanathan,B.Tech Computer Science & Engineering,2026,Regular
234567890123,ROLL-002,Kavya Sundaram,B.Tech Information Technology,2026,Regular
345678901234,ROLL-003,Deepak Sharma,B.Tech Aeronautical Engineering,2026,NRI`;
    const blob = new Blob([templateContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'AICTE_APAAR_Batch_Upload_Template.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleCommitUpload = () => {
    if (!csvContent) return;
    setIsProcessing(true);

    setTimeout(() => {
      const result = apiService.uploadBatch(institution.id, csvContent);
      setIsProcessing(false);
      setUploadFeedback({
        success: true,
        total: result.total,
        valid: result.valid,
        warnings: result.warnings,
        duplicates: result.duplicates
      });
      onUploadSuccess();
    }, 400);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-md flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 font-mono">
              POST /api/v1/students/upload-batch
            </span>
            <span className="text-xs text-slate-400">Automated Intake & APAAR Validator</span>
          </div>
          <h1 className="text-xl font-bold text-white mt-1">
            Student Batch Upload & Ingestion Engine
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Target College: <strong className="text-slate-200">{institution.name}</strong> ({institution.aicte_id})
          </p>
        </div>

        {/* Change Target College Dropdown */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <label className="text-slate-400">Upload Target:</label>
          <select
            value={institution.id}
            onChange={(e) => onSelectInstitution(e.target.value)}
            className="px-3 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-white text-xs cursor-pointer focus:outline-hidden"
          >
            {institutions.map((inst) => (
              <option key={inst.id} value={inst.id}>
                {inst.name.split(',')[0]} ({inst.aicte_id})
              </option>
            ))}
          </select>
          <button
            onClick={handleDownloadTemplate}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-medium flex items-center gap-1.5 transition cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-indigo-400" />
            <span>CSV Template</span>
          </button>
        </div>
      </div>

      {/* Upload Box & Dropzone */}
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`border-2 border-dashed rounded-2xl p-8 text-center transition ${
          isDragging
            ? 'border-indigo-500 bg-indigo-500/10'
            : 'border-slate-700/80 bg-slate-900/60 hover:border-slate-600'
        }`}
      >
        <div className="max-w-md mx-auto space-y-4">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-indigo-600/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
            <UploadCloud className="w-7 h-7" />
          </div>

          <div>
            <h3 className="font-semibold text-white text-base">
              Drag & Drop Student Roster CSV / Excel
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Supports CSV with 12-digit APAAR IDs, Roll Numbers, Degree Programs, and Admission Categories
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3">
            <label className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-xs cursor-pointer shadow-md transition flex items-center gap-1.5">
              <FileSpreadsheet className="w-4 h-4" />
              <span>Browse Local File</span>
              <input
                type="file"
                accept=".csv,.txt"
                onChange={handleFileUpload}
                className="hidden"
              />
            </label>

            <span className="text-xs text-slate-500">or</span>

            {/* Instant Demo Batch Loader Button */}
            <button
              type="button"
              onClick={handleLoadSampleBatch}
              className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-medium text-xs shadow-md transition flex items-center gap-1.5 cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-amber-200" />
              <span>Load Sample Batch (Demo)</span>
            </button>
          </div>

          <div className="text-[11px] text-slate-500 flex items-center justify-center gap-1.5">
            <Info className="w-3.5 h-3.5" />
            <span>Sample batch contains valid records, a duplicate conflict, and a 10-digit warning record.</span>
          </div>
        </div>
      </div>

      {/* Successful Upload Banner */}
      {uploadFeedback && (
        <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex flex-wrap sm:flex-nowrap items-center justify-between gap-4 text-xs text-emerald-200 animate-in fade-in">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <div>
              <strong className="text-white block font-semibold">
                Batch Successfully Committed to PostgreSQL Database!
              </strong>
              <span>
                Ingested {uploadFeedback.total} records: {uploadFeedback.valid} Valid, {uploadFeedback.duplicates} Duplicate alerts, {uploadFeedback.warnings} Warnings.
              </span>
            </div>
          </div>
          <button
            onClick={() => onNavigate('validation-results')}
            className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-medium rounded-lg transition cursor-pointer flex items-center gap-1.5 shrink-0"
          >
            <span>Inspect in Validation Table</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Pre-Commit Staging & Inline Error Preview */}
      {previewRows.length > 0 && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-lg space-y-4 p-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <FileCheck2 className="w-4 h-4 text-indigo-400" />
                Pre-Ingestion Automated Validation Preview ({fileName})
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Evaluated against National APAAR Registry & AICTE Sanctioned Intake before committing to database
              </p>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => {
                  setPreviewRows([]);
                  setCsvContent('');
                  setFileName('');
                }}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-white transition cursor-pointer"
              >
                Clear Preview
              </button>
              <button
                onClick={handleCommitUpload}
                disabled={isProcessing}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl shadow-lg transition flex items-center gap-2 cursor-pointer"
              >
                {isProcessing ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Processing Pandas Validation...</span>
                  </>
                ) : (
                  <>
                    <span>Commit {previewRows.length} Records to PostgreSQL</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Table Container */}
          <div className="overflow-x-auto border border-slate-800 rounded-xl">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-3">#</th>
                  <th className="py-2.5 px-3">Validation Status</th>
                  <th className="py-2.5 px-3">APAAR ID (12-Digit)</th>
                  <th className="py-2.5 px-3">Student Name</th>
                  <th className="py-2.5 px-3">College Roll No</th>
                  <th className="py-2.5 px-3">Program</th>
                  <th className="py-2.5 px-3">Category</th>
                  <th className="py-2.5 px-3">Engine Diagnostic</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-sans">
                {previewRows.map((row, idx) => {
                  const isDup = row.computedStatus === 'Duplicate';
                  const isWarn = row.computedStatus === 'Warning' || row.computedStatus === 'Needs Review';
                  return (
                    <tr
                      key={idx}
                      className={
                        isDup
                          ? 'bg-rose-950/20 hover:bg-rose-950/30'
                          : isWarn
                          ? 'bg-amber-950/20 hover:bg-amber-950/30'
                          : 'hover:bg-slate-800/40'
                      }
                    >
                      <td className="py-2.5 px-3 text-slate-500 font-mono">{idx + 1}</td>
                      <td className="py-2.5 px-3">
                        <span
                          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold ${
                            row.computedStatus === 'Valid'
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                              : isDup
                              ? 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                              : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                          }`}
                        >
                          {row.computedStatus === 'Valid' && <CheckCircle2 className="w-3 h-3" />}
                          {isDup && <AlertTriangle className="w-3 h-3" />}
                          {isWarn && <AlertTriangle className="w-3 h-3" />}
                          {row.computedStatus}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 font-mono font-medium text-white">
                        {row.apaar_id || <span className="text-rose-400 italic">Missing</span>}
                      </td>
                      <td className="py-2.5 px-3 font-medium text-slate-200">{row.full_name}</td>
                      <td className="py-2.5 px-3 text-slate-400 font-mono">{row.student_id}</td>
                      <td className="py-2.5 px-3 text-slate-300">{row.program}</td>
                      <td className="py-2.5 px-3 text-slate-400">{row.admission_category}</td>
                      <td className="py-2.5 px-3 text-[11px] text-slate-400 max-w-xs truncate" title={row.notes}>
                        {row.notes}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
