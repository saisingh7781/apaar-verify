/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Gauge,
  AlertTriangle,
  CheckCircle2,
  Building,
  TrendingUp,
  ShieldAlert,
  ArrowUpRight,
  Info
} from 'lucide-react';
import { Institution, Student, IntakeAnalysis } from '../../types.ts';
import { calculateIntakeAnalysis } from '../../utils/validation.ts';

interface IntakeMonitoringScreenProps {
  institutions: Institution[];
  students: Student[];
  selectedInstitutionId: string;
  onSelectInstitution: (id: string) => void;
}

export const IntakeMonitoringScreen: React.FC<IntakeMonitoringScreenProps> = ({
  institutions,
  students,
  selectedInstitutionId,
  onSelectInstitution
}) => {
  const currentInstitution =
    institutions.find((i) => i.id === selectedInstitutionId) || institutions[0];

  const currentAnalysis = calculateIntakeAnalysis(currentInstitution, students);

  // Calculate all analyses for comparative overview
  const allAnalyses = institutions.map((inst) =>
    calculateIntakeAnalysis(inst, students)
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-md flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 font-mono">
              GET /api/v1/monitoring/intake-check/{'{institution_id}'}
            </span>
            <span className="text-xs text-slate-400">Real-Time Headcount Enforcement</span>
          </div>
          <h1 className="text-xl font-bold text-white mt-1">
            Institutional Intake & Sanctioned Seat Cap Monitor
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time tracking of actual student admissions against AICTE Approval Orders
          </p>
        </div>

        {/* Institution Selector */}
        <div className="flex items-center gap-2 text-xs">
          <label className="text-slate-400 font-medium">Select Institution:</label>
          <select
            value={currentInstitution.id}
            onChange={(e) => onSelectInstitution(e.target.value)}
            className="px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-white text-xs font-semibold focus:outline-hidden focus:border-indigo-500 cursor-pointer"
          >
            {institutions.map((inst) => (
              <option key={inst.id} value={inst.id}>
                {inst.name.split(',')[0]} ({inst.aicte_id})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Capacity Exceeded Warning Banner (e.g. PSG Tech: 95/90) */}
      {currentAnalysis.is_exceeded && (
        <div className="p-5 rounded-2xl bg-rose-500/10 border-2 border-rose-500/60 shadow-lg text-rose-200 space-y-3 animate-in fade-in">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-start gap-3">
              <ShieldAlert className="w-6 h-6 text-rose-400 shrink-0 mt-0.5 animate-pulse" />
              <div>
                <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                  SANCTIONED CAPACITY BREACH DETECTED
                  <span className="px-2.5 py-0.5 rounded-full text-xs bg-rose-600 text-white font-bold">
                    +{currentAnalysis.excess_count} Unsanctioned Seats
                  </span>
                </h3>
                <p className="text-xs text-rose-200 mt-1 leading-relaxed">
                  <strong>{currentInstitution.name}</strong> has enrolled{' '}
                  <strong className="text-white underline">{currentAnalysis.enrolled_count} students</strong> against an official sanctioned quota of{' '}
                  <strong className="text-white underline">{currentInstitution.approved_intake} seats</strong>{' '}
                  ({currentAnalysis.utilization_percentage}% utilization).
                </p>
              </div>
            </div>
          </div>
          <div className="text-[11px] bg-rose-950/40 p-3 rounded-xl border border-rose-800/60 flex items-center justify-between">
            <span>
              Action Required: Automated non-compliance referral dispatched to AICTE Central Regional Office.
            </span>
            <span className="font-semibold text-rose-300 uppercase tracking-wide">
              APH 2026-27 Rule 4.2 Applicable
            </span>
          </div>
        </div>
      )}

      {/* Main Institution Gauge Card */}
      <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-md space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="text-xs text-indigo-400 font-semibold uppercase tracking-wider">
              {currentInstitution.aicte_id} • {currentInstitution.state}
            </div>
            <h2 className="text-xl font-bold text-white mt-0.5">{currentInstitution.name}</h2>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-right">
              <span className="text-xs text-slate-400 block">Seat Utilization</span>
              <span
                className={`text-2xl font-extrabold ${
                  currentAnalysis.is_exceeded
                    ? 'text-rose-400'
                    : currentAnalysis.utilization_percentage > 90
                    ? 'text-amber-400'
                    : 'text-emerald-400'
                }`}
              >
                {currentAnalysis.utilization_percentage}%
              </span>
            </div>
          </div>
        </div>

        {/* Progress Bar matching Sanctioned Capacity vs Actual Admissions */}
        <div className="space-y-2">
          <div className="flex justify-between text-xs">
            <span className="text-slate-400 font-medium">
              Actual Headcount:{' '}
              <strong className="text-white font-mono text-sm">{currentAnalysis.enrolled_count}</strong> students
            </span>
            <span className="text-slate-400 font-medium">
              Sanctioned Batch Cap:{' '}
              <strong className="text-indigo-300 font-mono text-sm">{currentInstitution.approved_intake}</strong> seats
            </span>
          </div>

          <div className="w-full bg-slate-950 h-5 rounded-full p-1 border border-slate-800 relative overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                currentAnalysis.is_exceeded
                  ? 'bg-gradient-to-r from-amber-500 to-rose-600'
                  : currentAnalysis.utilization_percentage > 85
                  ? 'bg-gradient-to-r from-emerald-500 to-amber-500'
                  : 'bg-emerald-500'
              }`}
              style={{
                width: `${Math.min(
                  (currentAnalysis.enrolled_count / currentInstitution.approved_intake) * 100,
                  100
                )}%`
              }}
            />
          </div>

          <div className="flex justify-between text-[11px] text-slate-500 pt-1">
            <span>0 Seats</span>
            <span>Safety Threshold: 85%</span>
            <span>100% Approved Cap ({currentInstitution.approved_intake})</span>
            {currentAnalysis.is_exceeded && (
              <span className="text-rose-400 font-bold">
                Exceeded: {currentAnalysis.enrolled_count} seats
              </span>
            )}
          </div>
        </div>

        {/* 3 Metric Pills */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-[11px] text-slate-400 block font-medium">Approved Intake</span>
            <span className="text-xl font-bold text-white font-mono">{currentInstitution.approved_intake}</span>
            <span className="text-[10px] text-slate-500 block mt-0.5">Maximum permitted by AICTE</span>
          </div>
          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-[11px] text-slate-400 block font-medium">Registered APAAR Count</span>
            <span className="text-xl font-bold text-white font-mono">{currentAnalysis.enrolled_count}</span>
            <span className="text-[10px] text-slate-500 block mt-0.5">Active verified students</span>
          </div>
          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
            <span className="text-[11px] text-slate-400 block font-medium">Seat Vacancy / Deficit</span>
            <span
              className={`text-xl font-bold font-mono ${
                currentAnalysis.is_exceeded ? 'text-rose-400' : 'text-emerald-400'
              }`}
            >
              {currentAnalysis.is_exceeded
                ? `-${currentAnalysis.excess_count} Excess`
                : `${currentInstitution.approved_intake - currentAnalysis.enrolled_count} Vacant`}
            </span>
            <span className="text-[10px] text-slate-500 block mt-0.5">
              {currentAnalysis.is_exceeded ? 'Over-enrollment violation' : 'Available sanctioned seats'}
            </span>
          </div>
        </div>
      </div>

      {/* Program Breakdown Cards */}
      <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-md space-y-4">
        <div>
          <h3 className="font-bold text-base text-white">Program-Wise Headcount Breakdown</h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Admissions segregated by degree program under {currentInstitution.name}
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Object.entries(currentAnalysis.program_breakdown).map(([prog, count]) => {
            const pct = Math.round((count / currentAnalysis.enrolled_count) * 100) || 0;
            return (
              <div
                key={prog}
                className="p-4 bg-slate-950 rounded-xl border border-slate-800/80 space-y-2 hover:border-slate-700 transition"
              >
                <div className="flex justify-between items-start gap-2">
                  <h4 className="font-semibold text-xs text-slate-200 line-clamp-1" title={prog}>
                    {prog}
                  </h4>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 shrink-0">
                    {count} Students
                  </span>
                </div>
                <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-indigo-500 h-full rounded-full transition-all"
                    style={{ width: `${pct}%` }}
                  />
                </div>
                <div className="flex justify-between text-[11px] text-slate-500">
                  <span>Share of College Total</span>
                  <span>{pct}%</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Comparative Overview across all colleges */}
      <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-md space-y-4">
        <div>
          <h3 className="font-bold text-base text-white">All Institutions Quota Comparison</h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Cross-institutional benchmark tracking sanctioned capacity vs enrolled student count
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">AICTE ID</th>
                <th className="py-2.5 px-3">Institution Name</th>
                <th className="py-2.5 px-3">State</th>
                <th className="py-2.5 px-3">Sanctioned Intake</th>
                <th className="py-2.5 px-3">Enrolled Count</th>
                <th className="py-2.5 px-3">Utilization</th>
                <th className="py-2.5 px-3">Compliance Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-sans">
              {allAnalyses.map((analysis) => {
                const isOver = analysis.is_exceeded;
                return (
                  <tr
                    key={analysis.institution_id}
                    className={`hover:bg-slate-800/40 cursor-pointer ${
                      analysis.institution_id === currentInstitution.id ? 'bg-indigo-950/20' : ''
                    }`}
                    onClick={() => onSelectInstitution(analysis.institution_id)}
                  >
                    <td className="py-3 px-3 font-mono font-semibold text-slate-300">
                      {analysis.aicte_id}
                    </td>
                    <td className="py-3 px-3 font-semibold text-white">
                      {analysis.institution_name}
                    </td>
                    <td className="py-3 px-3 text-slate-400">Tamil Nadu</td>
                    <td className="py-3 px-3 font-mono text-slate-300">
                      {analysis.approved_intake} seats
                    </td>
                    <td className="py-3 px-3 font-mono font-bold text-white">
                      {analysis.enrolled_count}
                    </td>
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-2">
                        <span className={`font-bold ${isOver ? 'text-rose-400' : 'text-slate-300'}`}>
                          {analysis.utilization_percentage}%
                        </span>
                        <div className="w-16 bg-slate-800 h-1.5 rounded-full overflow-hidden">
                          <div
                            className={`h-full ${isOver ? 'bg-rose-500' : 'bg-emerald-500'}`}
                            style={{ width: `${Math.min(analysis.utilization_percentage, 100)}%` }}
                          />
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-3">
                      {isOver ? (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/15 text-rose-400 border border-rose-500/30">
                          <AlertTriangle className="w-3 h-3" />
                          Breached (+{analysis.excess_count})
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                          <CheckCircle2 className="w-3 h-3" />
                          Compliant
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
