/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Building2,
  Shield,
  UserCheck,
  Search,
  QrCode,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Sparkles,
  Lock,
  Smartphone,
  GraduationCap,
  Layers,
  FileCheck2,
  Briefcase,
  ExternalLink
} from 'lucide-react';
import { Institution, Student } from '../../types.ts';
import { apiService, VerificationResult } from '../../services/apiService.ts';
import { isValidApaarId } from '../../utils/validation.ts';

interface FrontLandingPageProps {
  onNavigateToLogin: (role: 'institution_admin' | 'aicte_regulator' | 'student') => void;
  onNavigateToPortal: (role: 'institution_admin' | 'aicte_regulator' | 'student') => void;
  onTriggerAlert: (result: VerificationResult) => void;
  institutions: Institution[];
  students: Student[];
}

export const FrontLandingPage: React.FC<FrontLandingPageProps> = ({
  onNavigateToLogin,
  onNavigateToPortal,
  onTriggerAlert,
  institutions,
  students
}) => {
  const [quickSearchId, setQuickSearchId] = useState('1234-5678-9012');
  const [quickVerifier, setQuickVerifier] = useState('Tata Consultancy Services (TCS) Campus Verification Desk');
  const [publicResult, setPublicResult] = useState<VerificationResult | null>(null);
  const [isSearching, setIsSearching] = useState(false);

  const handleQuickVerify = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!quickSearchId.trim()) return;

    setIsSearching(true);
    setTimeout(() => {
      const res = apiService.verifyCredential(
        quickSearchId,
        quickVerifier || 'Public Verification Search Widget',
        '103.246.40.' + Math.floor(10 + Math.random() * 80)
      );
      setPublicResult(res);
      setIsSearching(false);
      onTriggerAlert(res);
    }, 250);
  };

  return (
    <div className="space-y-10 pb-12">
      {/* 1. Hero Section */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-slate-900 via-slate-900/90 to-indigo-950/40 border border-slate-800 p-6 sm:p-12 shadow-2xl">
        <div className="max-w-4xl mx-auto text-center space-y-6">
          {/* Government / NEP Ribbon */}
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-800/80 border border-slate-700/80 text-xs font-semibold text-slate-300 shadow-xs">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Ministry of Education & AICTE Initiative</span>
            <span className="text-slate-500">•</span>
            <span className="text-amber-400">National NEP 2020 Framework</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight leading-tight">
            AICTE <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-orange-400 to-indigo-400">APAAR</span> Student Data & Verification Platform
          </h1>

          <p className="text-xs sm:text-sm md:text-base text-slate-300 max-w-2xl mx-auto leading-relaxed">
            A centralized digital trust architecture anchored on the 12-digit national <strong>APAAR / ABC ID</strong>. Eliminates institutional data asymmetry, automates duplicate enrollment detection across Indian universities, and enforces sanctioned intake caps in real time.
          </p>

          {/* Quick Metrics Badges */}
          <div className="pt-2 flex flex-wrap items-center justify-center gap-4 sm:gap-6 text-xs text-slate-300">
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-950/60 border border-slate-800">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>100% Student Data Integrity</span>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-950/60 border border-slate-800">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Real-Time Seat Cap Enforcement</span>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-950/60 border border-slate-800">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Instant Student Privacy SMS Alerts</span>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Portal Gateway Cards (Symmetrical 4-Card Responsive Grid) */}
      <section className="space-y-5">
        <div className="text-center space-y-1">
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            Role-Based Portal Gateways
          </h2>
          <p className="text-xs sm:text-sm text-slate-400">
            Secure entry points with strict role-based access control (RBAC) across technical education stakeholders
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {/* Gateway Card 1: Institution Portal */}
          <div className="bg-slate-900 border border-slate-800 hover:border-indigo-500/60 rounded-3xl p-5 shadow-xl flex flex-col justify-between transition group hover:shadow-indigo-500/10">
            <div className="space-y-3.5">
              <div className="w-11 h-11 rounded-2xl bg-indigo-600/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 group-hover:scale-105 transition">
                <Building2 className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-400 block mb-1">
                  Colleges & Universities
                </span>
                <h3 className="text-base font-bold text-white group-hover:text-indigo-300 transition">
                  Institution Portal
                </h3>
                <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
                  For college administrators to upload student rosters, manage admissions, and monitor intake compliance.
                </p>
              </div>

              <div className="pt-2 space-y-1 text-[11px] text-slate-400">
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                  <span>Batch CSV/Excel ingestion</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                  <span>Inline duplicate anomaly tags</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                  <span>Seat cap utilization gauges</span>
                </div>
              </div>
            </div>

            <div className="mt-5 pt-3.5 border-t border-slate-800">
              <button
                onClick={() => onNavigateToLogin('institution_admin')}
                className="w-full py-2.5 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md transition flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span>Institution Login</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition" />
              </button>
            </div>
          </div>

          {/* Gateway Card 2: AICTE Regulator Portal */}
          <div className="bg-slate-900 border border-slate-800 hover:border-emerald-500/60 rounded-3xl p-5 shadow-xl flex flex-col justify-between transition group hover:shadow-emerald-500/10">
            <div className="space-y-3.5">
              <div className="w-11 h-11 rounded-2xl bg-emerald-600/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 group-hover:scale-105 transition">
                <Shield className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400 block mb-1">
                  National Councils
                </span>
                <h3 className="text-base font-bold text-white group-hover:text-emerald-300 transition">
                  AICTE Regulator Portal
                </h3>
                <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
                  For national regulators to view real-time compliance grids, excess intake breach feeds, and macro-analytics.
                </p>
              </div>

              <div className="pt-2 space-y-1 text-[11px] text-slate-400">
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>Macro compliance overview</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>Excess intake breach alerts</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>Statutory inquiry dispatch</span>
                </div>
              </div>
            </div>

            <div className="mt-5 pt-3.5 border-t border-slate-800">
              <button
                onClick={() => onNavigateToLogin('aicte_regulator')}
                className="w-full py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-md transition flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span>Regulator Login</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition" />
              </button>
            </div>
          </div>

          {/* Gateway Card 3: Citizen / Student Portal */}
          <div className="bg-slate-900 border border-slate-800 hover:border-amber-500/60 rounded-3xl p-5 shadow-xl flex flex-col justify-between transition group hover:shadow-amber-500/10 relative overflow-hidden">
            <div className="absolute top-3 right-3 px-2 py-0.5 rounded-full text-[9px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
              Citizen First
            </div>

            <div className="space-y-3.5">
              <div className="w-11 h-11 rounded-2xl bg-amber-600/10 border border-amber-500/20 flex items-center justify-center text-amber-400 group-hover:scale-105 transition">
                <UserCheck className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400 block mb-1">
                  Students & Citizens
                </span>
                <h3 className="text-base font-bold text-white group-hover:text-amber-300 transition">
                  Citizen / Student Portal
                </h3>
                <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
                  For students to audit their academic record, view real-time access logs, and toggle consent locks.
                </p>
              </div>

              <div className="pt-2 space-y-1 text-[11px] text-slate-400">
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>My Academic Profile & Card</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>Live access audit trail ledger</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span>Consent lock/unlock control</span>
                </div>
              </div>
            </div>

            <div className="mt-5 pt-3.5 border-t border-slate-800">
              <button
                onClick={() => onNavigateToLogin('student')}
                className="w-full py-2.5 px-3 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold shadow-md transition flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span>Student Portal Login</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition" />
              </button>
            </div>
          </div>

          {/* Gateway Card 4: Trusted Organizations & Employers */}
          <div className="bg-slate-900 border border-slate-800 hover:border-sky-500/60 rounded-3xl p-5 shadow-xl flex flex-col justify-between transition group hover:shadow-sky-500/10 relative overflow-hidden">
            <div className="space-y-3.5">
              <div className="w-11 h-11 rounded-2xl bg-sky-600/10 border border-sky-500/20 flex items-center justify-center text-sky-400 group-hover:scale-105 transition">
                <Briefcase className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-sky-400 block mb-1">
                  Trusted Organizations
                </span>
                <h3 className="text-base font-bold text-white group-hover:text-sky-300 transition">
                  Employers & Agencies
                </h3>
                <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
                  For corporate recruiters (TCS, AWS, Infosys) and verification desks to verify degrees with student-consented transparent logging.
                </p>
              </div>

              <div className="pt-2 space-y-1 text-[11px] text-slate-400">
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                  <span>Optical QR code scanning</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                  <span>12-digit instant APAAR lookup</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                  <span>Anti-tamper SHA-256 seal</span>
                </div>
              </div>
            </div>

            <div className="mt-5 pt-3.5 border-t border-slate-800">
              <button
                onClick={() => {
                  const el = document.getElementById('public-verify-section');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className="w-full py-2.5 px-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold shadow-md transition flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span>Verify Credentials</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Quick Public Verification Widget */}
      <section
        id="public-verify-section"
        className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl space-y-6"
      >
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 text-xs text-indigo-400 font-semibold mb-1">
              <Search className="w-3.5 h-3.5" />
              Public Credential Verification Service
            </div>
            <h3 className="text-xl font-bold text-white">
              Instant Employer & Third-Party Credential Lookup
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Verify degree enrollment or student credentials without an account. Each lookup automatically dispatches a security SMS alert to the student.
            </p>
          </div>
          <span className="px-3 py-1 rounded-full text-xs font-semibold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 font-mono">
            No Login Required
          </span>
        </div>

        {/* Input Form */}
        <form onSubmit={handleQuickVerify} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
            <div className="md:col-span-5">
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Enter 12-Digit APAAR / ABC ID
              </label>
              <input
                type="text"
                value={quickSearchId}
                onChange={(e) => setQuickSearchId(e.target.value)}
                placeholder="e.g. 1234-5678-9012"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono text-xs focus:outline-hidden focus:border-indigo-500"
                required
              />
            </div>
            <div className="md:col-span-5">
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Querying Organization / Employer Name
              </label>
              <input
                type="text"
                value={quickVerifier}
                onChange={(e) => setQuickVerifier(e.target.value)}
                placeholder="e.g. Tata Consultancy Services or Deloitte USI"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs focus:outline-hidden focus:border-indigo-500"
                required
              />
            </div>
            <div className="md:col-span-2 flex items-end">
              <button
                type="submit"
                disabled={isSearching}
                className="w-full py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs shadow-md transition flex items-center justify-center gap-1.5 cursor-pointer"
              >
                {isSearching ? (
                  <span>Checking...</span>
                ) : (
                  <>
                    <Search className="w-3.5 h-3.5" />
                    <span>Verify Now</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </form>

        {/* Quick Sample Clickers */}
        <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
          <span className="text-slate-400 font-medium">Quick Demo Samples:</span>
          <button
            type="button"
            onClick={() => {
              setQuickSearchId('123456789012');
              setQuickVerifier('Tata Consultancy Services (TCS)');
            }}
            className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition cursor-pointer"
          >
            Aarav Ramanathan (MIT)
          </button>
          <button
            type="button"
            onClick={() => {
              setQuickSearchId('548291037462');
              setQuickVerifier('Anna University Transcript Desk');
            }}
            className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-rose-300 border border-rose-900/60 transition cursor-pointer"
          >
            Siddharth (Duplicate Conflict)
          </button>
          <button
            type="button"
            onClick={() => {
              setQuickSearchId('234567890123');
              setQuickVerifier('Amazon Web Services');
            }}
            className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition cursor-pointer"
          >
            Kavya Sundaram (MIT)
          </button>
        </div>

        {/* Inline Public Result Preview */}
        {publicResult && (
          <div className="mt-4 p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3 animate-in fade-in">
            {publicResult.isLocked ? (
              <div className="flex items-start gap-3 text-rose-300">
                <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-sm text-white">Verification Blocked by Student</h4>
                  <p className="text-xs text-slate-300 mt-1">
                    The student has enabled <strong>Consent Privacy Lock</strong> on their APAAR account. Direct third-party verification is disabled until the student unlocks sharing in their Citizen Portal. An alert has been sent to the student's mobile.
                  </p>
                </div>
              </div>
            ) : publicResult.verified && publicResult.student ? (
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      ✓ AICTE & DigiLocker Verified
                    </span>
                    <span className="text-xs text-slate-400 font-mono">
                      APAAR: {isValidApaarId(publicResult.student.apaar_id).formatted}
                    </span>
                  </div>
                  <h4 className="text-base font-bold text-white">
                    {publicResult.student.full_name}
                  </h4>
                  <p className="text-xs text-slate-300">
                    {publicResult.student.program} • {publicResult.institution?.name} • Batch {publicResult.student.admission_year}
                  </p>
                </div>
                <div className="text-right text-xs">
                  <span className="text-emerald-400 font-semibold block flex items-center gap-1 justify-end">
                    <Smartphone className="w-3.5 h-3.5" /> SMS Alert Dispatched
                  </span>
                  <span className="text-slate-400 text-[11px]">
                    Delivered to student's mobile
                  </span>
                </div>
              </div>
            ) : (
              <div className="text-xs text-amber-300 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-400" />
                <span>No verified academic record found for APAAR ID: {publicResult.auditLog.apaar_id}</span>
              </div>
            )}
          </div>
        )}
      </section>

      {/* 4. Architecture Specifications Banner */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-1.5">
          <div className="flex items-center gap-2 text-indigo-400 font-semibold">
            <Layers className="w-4 h-4" />
            <span>National ABC Repository</span>
          </div>
          <p className="text-slate-400 leading-relaxed">
            Synchronizes with the Academic Bank of Credits and DigiLocker for permanent student credential mobility.
          </p>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-1.5">
          <div className="flex items-center gap-2 text-emerald-400 font-semibold">
            <FileCheck2 className="w-4 h-4" />
            <span>Automated Duplicate Engine</span>
          </div>
          <p className="text-slate-400 leading-relaxed">
            Flags multi-college concurrent admissions and fraudulent duplicate seat blocking before approvals finalize.
          </p>
        </div>

        <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-1.5">
          <div className="flex items-center gap-2 text-amber-400 font-semibold">
            <Lock className="w-4 h-4" />
            <span>Student Consent Sovereignty</span>
          </div>
          <p className="text-slate-400 leading-relaxed">
            Students retain total ownership of their academic identity with instant access audit logs and lock controls.
          </p>
        </div>
      </section>
    </div>
  );
};
