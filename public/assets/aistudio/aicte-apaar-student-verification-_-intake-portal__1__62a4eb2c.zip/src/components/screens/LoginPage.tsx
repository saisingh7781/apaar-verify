/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Shield,
  Building2,
  Lock,
  Mail,
  ArrowRight,
  CheckCircle2,
  KeyRound,
  Sparkles,
  UserCheck,
  Smartphone,
  Fingerprint
} from 'lucide-react';
import { apiService, UserSession } from '../../services/apiService.ts';
import { Institution, Student, UserRole } from '../../types.ts';
import { isValidApaarId } from '../../utils/validation.ts';

interface LoginPageProps {
  initialRole?: UserRole;
  onLoginSuccess: (session: UserSession) => void;
  institutions: Institution[];
  students: Student[];
}

export const LoginPage: React.FC<LoginPageProps> = ({
  initialRole = 'institution_admin',
  onLoginSuccess,
  institutions,
  students
}) => {
  const [role, setRole] = useState<UserRole>(initialRole);
  const [selectedInstitutionId, setSelectedInstitutionId] = useState<string>(institutions[0]?.id || 'inst-1');
  const [email, setEmail] = useState('registrar@mitindia.edu');
  const [password, setPassword] = useState('••••••••••••');
  const [studentApaarId, setStudentApaarId] = useState('1234-5678-9012');
  const [studentOtp, setStudentOtp] = useState('849201');
  const [otpSent, setOtpSent] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (initialRole) {
      setRole(initialRole);
    }
  }, [initialRole]);

  const handleRoleChange = (newRole: UserRole) => {
    setRole(newRole);
    if (newRole === 'aicte_regulator') {
      setEmail('regulator.hq@aicte-india.org');
    } else if (newRole === 'institution_admin') {
      setEmail('registrar@mitindia.edu');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    setTimeout(() => {
      let session: UserSession;
      if (role === 'student') {
        session = apiService.loginAsStudent(studentApaarId);
      } else {
        session = apiService.login(
          role,
          role === 'institution_admin' ? selectedInstitutionId : undefined,
          email
        );
      }
      setIsLoading(false);
      onLoginSuccess(session);
    }, 300);
  };

  const handleQuickDemoLogin = (targetRole: UserRole, targetId = 'inst-1') => {
    setIsLoading(true);
    setTimeout(() => {
      let session: UserSession;
      if (targetRole === 'student') {
        session = apiService.loginAsStudent(targetId || '123456789012');
      } else {
        session = apiService.login(
          targetRole,
          targetRole === 'institution_admin' ? targetId : undefined,
          targetRole === 'institution_admin' ? 'registrar@mitindia.edu' : 'regulator.hq@aicte-india.org'
        );
      }
      setIsLoading(false);
      onLoginSuccess(session);
    }, 200);
  };

  return (
    <div className="max-w-4xl mx-auto py-6 sm:py-10 px-4">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden grid md:grid-cols-12">
        {/* Left Side: National Scheme Info */}
        <div className="md:col-span-5 bg-gradient-to-br from-indigo-950 via-slate-900 to-slate-950 p-6 sm:p-8 flex flex-col justify-between border-b md:border-b-0 md:border-r border-slate-800 relative">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-orange-500 via-white to-emerald-500" />

          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-xs font-semibold mb-4">
              <Shield className="w-3.5 h-3.5" />
              National Academic Depository (NAD)
            </div>
            <h2 className="text-2xl font-bold text-white tracking-tight">
              AICTE APAAR Portal
            </h2>
            <p className="text-xs text-slate-300 mt-2 leading-relaxed">
              Automated student verification, duplicate enrollment detection, and real-time intake seat cap tracking for all AICTE-approved colleges.
            </p>

            <div className="mt-6 space-y-3 text-xs text-slate-300">
              <div className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Single 12-digit national student identity linked to Academic Bank of Credits (ABC).</span>
              </div>
              <div className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Zero duplicate admissions across universities or concurrent regular programs.</span>
              </div>
              <div className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Real-time student access alerts when employers or agencies verify credentials.</span>
              </div>
            </div>
          </div>

          <div className="mt-8 pt-6 border-t border-slate-800/80 text-[11px] text-slate-400">
            <p>API Endpoint: <code className="text-indigo-300 font-mono">POST /api/v1/auth/login</code></p>
            <p className="mt-1">Standard OAuth2 JWT Bearer Tokens with Role-Based Access.</p>
          </div>
        </div>

        {/* Right Side: Authentication Form */}
        <div className="md:col-span-7 p-6 sm:p-8 bg-slate-900 flex flex-col justify-center">
          <div className="mb-5">
            <h3 className="text-lg font-bold text-white">Sign In to Platform</h3>
            <p className="text-xs text-slate-400 mt-1">Select your authorized portal role below</p>
          </div>

          {/* Quick 1-Click Demo Buttons */}
          <div className="mb-5 p-3 bg-slate-800/50 rounded-xl border border-slate-800">
            <div className="text-[11px] font-semibold text-amber-400 flex items-center gap-1.5 mb-2">
              <Sparkles className="w-3.5 h-3.5" /> Quick Presentation Demo Shortcuts:
            </div>
            <div className="grid grid-cols-3 gap-1.5">
              <button
                type="button"
                onClick={() => handleQuickDemoLogin('institution_admin', 'inst-1')}
                className="px-2 py-1.5 rounded-lg bg-indigo-600/30 hover:bg-indigo-600/50 border border-indigo-500/40 text-indigo-200 text-[11px] font-medium text-left transition cursor-pointer"
              >
                <span className="block font-bold text-white truncate">College Admin</span>
                <span className="text-[10px] text-indigo-300">MIT Chennai</span>
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemoLogin('aicte_regulator')}
                className="px-2 py-1.5 rounded-lg bg-emerald-600/30 hover:bg-emerald-600/50 border border-emerald-500/40 text-emerald-200 text-[11px] font-medium text-left transition cursor-pointer"
              >
                <span className="block font-bold text-white truncate">AICTE Regulator</span>
                <span className="text-[10px] text-emerald-300">National HQ</span>
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemoLogin('student', '123456789012')}
                className="px-2 py-1.5 rounded-lg bg-amber-600/30 hover:bg-amber-600/50 border border-amber-500/40 text-amber-200 text-[11px] font-medium text-left transition cursor-pointer"
              >
                <span className="block font-bold text-white truncate">Student Citizen</span>
                <span className="text-[10px] text-amber-300">Aarav (MIT)</span>
              </button>
            </div>
          </div>

          {/* 3-Way Role Selector Tabs */}
          <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-950 rounded-xl border border-slate-800 mb-5">
            <button
              type="button"
              onClick={() => handleRoleChange('institution_admin')}
              className={`flex items-center justify-center gap-1.5 py-2 px-2 rounded-lg text-xs font-semibold transition cursor-pointer ${
                role === 'institution_admin'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Building2 className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate">Institution</span>
            </button>
            <button
              type="button"
              onClick={() => handleRoleChange('aicte_regulator')}
              className={`flex items-center justify-center gap-1.5 py-2 px-2 rounded-lg text-xs font-semibold transition cursor-pointer ${
                role === 'aicte_regulator'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Shield className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate">AICTE Regulator</span>
            </button>
            <button
              type="button"
              onClick={() => handleRoleChange('student')}
              className={`flex items-center justify-center gap-1.5 py-2 px-2 rounded-lg text-xs font-semibold transition cursor-pointer ${
                role === 'student'
                  ? 'bg-amber-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <UserCheck className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate">Student</span>
            </button>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            {role === 'institution_admin' && (
              <>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    Select Approved Institution
                  </label>
                  <select
                    value={selectedInstitutionId}
                    onChange={(e) => setSelectedInstitutionId(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-lg bg-slate-800 border border-slate-700 text-white text-xs focus:outline-hidden focus:border-indigo-500 cursor-pointer"
                  >
                    {institutions.map((inst) => (
                      <option key={inst.id} value={inst.id}>
                        {inst.name} ({inst.aicte_id} — Intake: {inst.approved_intake})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    Official College Admin Email
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      className="w-full pl-9 pr-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-white text-xs focus:outline-hidden focus:border-indigo-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    Password / Secure Passkey
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      className="w-full pl-9 pr-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-white text-xs focus:outline-hidden focus:border-indigo-500"
                    />
                  </div>
                </div>
              </>
            )}

            {role === 'aicte_regulator' && (
              <>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    AICTE Official Regulator Email
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      className="w-full pl-9 pr-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-white text-xs focus:outline-hidden focus:border-indigo-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    Govt. 2FA Security Passkey
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      className="w-full pl-9 pr-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-white text-xs focus:outline-hidden focus:border-indigo-500"
                    />
                  </div>
                </div>
              </>
            )}

            {role === 'student' && (
              <>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    12-Digit National APAAR / ABC ID
                  </label>
                  <div className="relative">
                    <Fingerprint className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      value={studentApaarId}
                      onChange={(e) => setStudentApaarId(e.target.value)}
                      placeholder="1234-5678-9012"
                      required
                      className="w-full pl-9 pr-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-white font-mono text-xs focus:outline-hidden focus:border-amber-500"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-slate-300 font-medium">
                      One-Time Password (OTP)
                    </label>
                    <button
                      type="button"
                      onClick={() => setOtpSent(true)}
                      className="text-[11px] text-amber-400 hover:text-amber-300 font-medium cursor-pointer"
                    >
                      {otpSent ? '✓ OTP Sent to +91 98*** **412' : 'Send OTP to Mobile'}
                    </button>
                  </div>
                  <div className="relative">
                    <Smartphone className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      value={studentOtp}
                      onChange={(e) => setStudentOtp(e.target.value)}
                      placeholder="Enter 6-digit OTP"
                      required
                      className="w-full pl-9 pr-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-white font-mono text-xs focus:outline-hidden focus:border-amber-500"
                    />
                  </div>
                </div>

                {/* DigiLocker Button Alternative */}
                <div className="pt-1">
                  <button
                    type="button"
                    onClick={() => handleQuickDemoLogin('student', '123456789012')}
                    className="w-full py-2 px-3 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-medium flex items-center justify-center gap-2 cursor-pointer transition"
                  >
                    <span className="w-2 h-2 rounded-full bg-emerald-400" />
                    <span>Instant Login with DigiLocker / Aadhaar e-KYC</span>
                  </button>
                </div>
              </>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className={`w-full py-2.5 rounded-lg font-semibold text-white shadow-lg transition flex items-center justify-center gap-2 cursor-pointer ${
                role === 'aicte_regulator'
                  ? 'bg-emerald-600 hover:bg-emerald-500'
                  : role === 'student'
                  ? 'bg-amber-600 hover:bg-amber-500'
                  : 'bg-indigo-600 hover:bg-indigo-500'
              }`}
            >
              {isLoading ? (
                <span>Verifying Credentials with AICTE Gateway...</span>
              ) : (
                <>
                  <span>
                    {role === 'student'
                      ? 'Access Student Academic Portal'
                      : role === 'aicte_regulator'
                      ? 'Enter Regulator Central Command'
                      : 'Launch Institution Dashboard'}
                  </span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
