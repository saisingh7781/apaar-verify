/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Student, AdmissionCategory } from '../types.ts';
import { X, Check, AlertTriangle, ShieldCheck } from 'lucide-react';
import { isValidApaarId } from '../utils/validation.ts';

interface EditStudentModalProps {
  student: Student | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (studentId: string, updates: Partial<Student>) => void;
}

export const EditStudentModal: React.FC<EditStudentModalProps> = ({
  student,
  isOpen,
  onClose,
  onSave
}) => {
  if (!isOpen || !student) return null;

  const [apaarId, setApaarId] = useState(student.apaar_id);
  const [studentId, setStudentId] = useState(student.student_id);
  const [fullName, setFullName] = useState(student.full_name);
  const [program, setProgram] = useState(student.program);
  const [admissionCategory, setAdmissionCategory] = useState<AdmissionCategory>(student.admission_category);
  const [admissionYear, setAdmissionYear] = useState(student.admission_year);

  const apaarValidation = isValidApaarId(apaarId);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(student.id, {
      apaar_id: apaarId,
      student_id: studentId,
      full_name: fullName,
      program,
      admission_category: admissionCategory,
      admission_year: admissionYear
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-lg shadow-2xl text-slate-100 overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-800/80 border-b border-slate-700/80 flex items-center justify-between">
          <div>
            <h3 className="font-semibold text-lg text-white">Edit & Correct Student Record</h3>
            <p className="text-xs text-slate-400">Resolve format errors or update national APAAR ID registry</p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-700 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-sm">
          {/* Current Status Callout */}
          <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 flex items-start gap-3">
            <div className="mt-0.5">
              {student.validation_status === 'Valid' ? (
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-amber-400" />
              )}
            </div>
            <div className="text-xs">
              <span className="font-medium text-slate-300">Current Status: </span>
              <strong className={
                student.validation_status === 'Valid' ? 'text-emerald-400' :
                student.validation_status === 'Duplicate' ? 'text-rose-400' : 'text-amber-400'
              }>
                {student.validation_status}
              </strong>
              {student.validation_notes && (
                <p className="text-slate-400 mt-0.5">{student.validation_notes}</p>
              )}
            </div>
          </div>

          {/* APAAR ID */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              National APAAR / ABC ID (12 Digits) *
            </label>
            <input
              type="text"
              value={apaarId}
              onChange={(e) => setApaarId(e.target.value)}
              placeholder="e.g. 123456789012"
              maxLength={14}
              required
              className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white font-mono focus:outline-hidden focus:border-indigo-500"
            />
            {apaarId.length > 0 && (
              <div className="mt-1 text-xs">
                {apaarValidation.valid ? (
                  <span className="text-emerald-400 flex items-center gap-1">
                    <Check className="w-3 h-3" /> Formatted: {apaarValidation.formatted} (Valid 12-digit format)
                  </span>
                ) : (
                  <span className="text-rose-400 flex items-center gap-1">
                    <AlertTriangle className="w-3 h-3" /> {apaarValidation.error}
                  </span>
                )}
              </div>
            )}
          </div>

          {/* Full Name & Student ID (Roll No) */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Full Name (Matches Aadhaar) *
              </label>
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                required
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-hidden focus:border-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Internal College Roll No *
              </label>
              <input
                type="text"
                value={studentId}
                onChange={(e) => setStudentId(e.target.value)}
                required
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white font-mono focus:outline-hidden focus:border-indigo-500"
              />
            </div>
          </div>

          {/* Program */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Program / Branch *
            </label>
            <input
              type="text"
              value={program}
              onChange={(e) => setProgram(e.target.value)}
              required
              className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-hidden focus:border-indigo-500"
            />
          </div>

          {/* Category & Year */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Admission Category *
              </label>
              <select
                value={admissionCategory}
                onChange={(e) => setAdmissionCategory(e.target.value as AdmissionCategory)}
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-hidden focus:border-indigo-500 cursor-pointer"
              >
                <option value="Regular">Regular</option>
                <option value="NRI">NRI Quota</option>
                <option value="OCI">OCI</option>
                <option value="Foreign National">Foreign National</option>
                <option value="Supernumerary">Supernumerary (PMSSS/Sports)</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Admission Year
              </label>
              <input
                type="number"
                value={admissionYear}
                onChange={(e) => setAdmissionYear(parseInt(e.target.value, 10))}
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-hidden focus:border-indigo-500"
              />
            </div>
          </div>

          {/* Footer Actions */}
          <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-medium shadow-md transition cursor-pointer flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              Save & Revalidate
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
