/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  GraduationCap,
  LayoutDashboard,
  UploadCloud,
  FileCheck2,
  Gauge,
  Building,
  QrCode,
  FileSpreadsheet,
  ShieldCheck,
  LogIn,
  LogOut,
  UserCheck,
  Home,
  Shield,
  Building2
} from 'lucide-react';
import { UserSession } from '../services/apiService.ts';

export type ScreenId =
  | 'landing'
  | 'login'
  | 'student-portal'
  | 'institution-dashboard'
  | 'student-upload'
  | 'validation-results'
  | 'intake-monitoring'
  | 'aicte-central'
  | 'verification-audit'
  | 'reports'
  | 'admin-security';

interface NavbarProps {
  currentScreen: ScreenId;
  onSelectScreen: (screen: ScreenId) => void;
  currentUser: UserSession | null;
  onLogout: () => void;
  stats: {
    duplicateCount: number;
    intakeBreached: boolean;
  };
}

export const Navbar: React.FC<NavbarProps> = ({
  currentScreen,
  onSelectScreen,
  currentUser,
  onLogout,
  stats
}) => {
  const isRegulator = currentUser?.role === 'aicte_regulator';
  const isStudent = currentUser?.role === 'student';
  const isInstitution = currentUser?.role === 'institution_admin';

  // Navigation Items
  const navItems: Array<{
    id: ScreenId;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: string | number;
    badgeColor?: string;
    highlight?: boolean;
    hideForRoles?: string[];
  }> = [
    {
      id: 'landing',
      label: 'Public Home',
      icon: Home
    },
    {
      id: 'student-portal',
      label: 'Student / Citizen Portal',
      icon: UserCheck,
      highlight: isStudent
    },
    {
      id: 'institution-dashboard',
      label: 'Institute Portal',
      icon: LayoutDashboard,
      hideForRoles: ['student']
    },
    {
      id: 'student-upload',
      label: 'Student Upload',
      icon: UploadCloud,
      hideForRoles: ['student', 'aicte_regulator']
    },
    {
      id: 'validation-results',
      label: 'Validation Engine',
      icon: FileCheck2,
      badge: stats.duplicateCount > 0 ? `${stats.duplicateCount} Alerts` : undefined,
      badgeColor: 'bg-rose-500 text-white',
      hideForRoles: ['student']
    },
    {
      id: 'intake-monitoring',
      label: 'Intake Monitor',
      icon: Gauge,
      badge: stats.intakeBreached ? 'Breach' : undefined,
      badgeColor: 'bg-amber-500 text-black font-bold animate-pulse',
      hideForRoles: ['student']
    },
    {
      id: 'aicte-central',
      label: 'AICTE Central Hub',
      icon: Building,
      highlight: isRegulator,
      hideForRoles: ['student']
    },
    {
      id: 'verification-audit',
      label: 'Credential Verification',
      icon: QrCode
    },
    {
      id: 'reports',
      label: 'Compliance Reports',
      icon: FileSpreadsheet,
      hideForRoles: ['student']
    },
    {
      id: 'admin-security',
      label: 'Admin Blueprint & RBAC',
      icon: ShieldCheck
    }
  ];

  const filteredNavItems = navItems.filter((item) => {
    if (!currentUser && (item.id === 'student-upload' || item.id === 'reports')) return false;
    if (item.hideForRoles && currentUser && item.hideForRoles.includes(currentUser.role)) {
      return false;
    }
    return true;
  });

  return (
    <nav className="bg-slate-900 border-b border-slate-800 sticky top-0 z-40">
      {/* Brand & Identity Bar */}
      <div className="max-w-7xl mx-auto px-4 py-3 flex flex-wrap items-center justify-between gap-4">
        {/* Brand */}
        <div
          onClick={() => onSelectScreen('landing')}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-orange-600 via-amber-500 to-indigo-600 p-0.5 shadow-lg group-hover:scale-105 transition">
            <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
              <GraduationCap className="w-5 h-5 text-amber-400" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-base tracking-tight text-white flex items-center gap-1.5">
                AICTE <span className="text-amber-400">APAAR</span> REGISTRY
              </span>
              <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-800">
                MoE / ABC
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-medium">
              National Student Data Management & Real-Time Intake Verification Platform
            </p>
          </div>
        </div>

        {/* User Status & Navigation Actions */}
        <div className="flex items-center gap-3 text-xs">
          {currentUser ? (
            <div className="flex items-center gap-3">
              <div className="text-right hidden sm:block">
                <div className="font-semibold text-slate-200">{currentUser.name}</div>
                <div className="text-slate-400 text-[11px] flex items-center gap-1 justify-end">
                  <span
                    className={`w-1.5 h-1.5 rounded-full ${
                      isRegulator
                        ? 'bg-indigo-400'
                        : isStudent
                        ? 'bg-amber-400'
                        : 'bg-emerald-400'
                    }`}
                  />
                  {isRegulator
                    ? 'AICTE Central Authority'
                    : isStudent
                    ? 'Verified Student Citizen'
                    : 'AICTE-TN-042 (MIT)'}
                </div>
              </div>
              <button
                onClick={onLogout}
                className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 hover:text-white transition cursor-pointer"
                title="Log out session"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Logout</span>
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={() => onSelectScreen('login')}
                className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold shadow transition cursor-pointer"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Portal Login</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Screen Tabs Bar */}
      <div className="border-t border-slate-800/80 bg-slate-950/60 overflow-x-auto scrollbar-none">
        <div className="max-w-7xl mx-auto px-4 flex space-x-1 py-1.5 min-w-max">
          {filteredNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentScreen === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectScreen(item.id)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer relative ${
                  isActive
                    ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/40 shadow-xs'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Icon
                  className={`w-3.5 h-3.5 ${
                    isActive
                      ? 'text-indigo-400'
                      : item.highlight
                      ? 'text-amber-400'
                      : 'text-slate-400'
                  }`}
                />
                <span>{item.label}</span>
                {item.badge && (
                  <span
                    className={`text-[10px] px-1.5 py-0.2 rounded-full font-semibold ${item.badgeColor}`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
};
