/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type ValidationStatus = 'Valid' | 'Warning' | 'Duplicate' | 'Needs Review';
export type AdmissionCategory = 'Regular' | 'NRI' | 'OCI' | 'Foreign National' | 'Supernumerary';
export type UserRole = 'institution_admin' | 'aicte_regulator' | 'student';

export interface Institution {
  id: string;
  aicte_id: string;
  name: string;
  state: string;
  approved_intake: number;
  programs?: string[];
}

export interface Student {
  id: string;
  apaar_id: string;
  student_id: string;
  full_name: string;
  program: string;
  admission_year: number;
  admission_category: AdmissionCategory;
  institution_id: string;
  validation_status: ValidationStatus;
  validation_notes?: string;
  created_at?: string;
  contact_masked?: string;
  is_sharing_locked?: boolean;
}

export interface AccessAuditLog {
  log_id: string;
  apaar_id: string;
  verifier_entity: string;
  access_timestamp: string;
  ip_address: string;
  alert_dispatched: boolean;
  student_name?: string;
  institution_name?: string;
}

export interface IntakeAnalysis {
  institution_id: string;
  institution_name: string;
  aicte_id: string;
  approved_intake: number;
  enrolled_count: number;
  utilization_percentage: number;
  is_exceeded: boolean;
  excess_count: number;
  program_breakdown: Record<string, number>;
}
